# Enterprise OS - Quick Start Guide

## Automated Installation

The Enterprise OS includes fully automated installation, configuration, and setup scripts.

### Prerequisites

- Ubuntu Server 22.04 LTS
- Minimum 8GB RAM, 4 CPU cores
- 50GB free disk space
- Root access

### Installation Steps

#### 1. Prepare Source Code
```bash
# Copy Enterprise OS source to /tmp
sudo cp -r /path/to/enterprise-os /tmp/
```

#### 2. Run Automated Installer
```bash
cd /tmp/enterprise-os
sudo chmod +x scripts/*.sh
sudo ./scripts/install-server.sh
```

This will:
- Install all dependencies (PostgreSQL, ZeroMQ, etc.)
- Build Enterprise OS from source
- Create system user and directories
- Generate secure passwords
- Configure systemd service
- Set up automated backups

**Duration:** ~15-20 minutes

#### 3. Initialize Database
```bash
sudo /opt/enterprise-os/scripts/init-database.sh
```

This will:
- Create database and tables
- Import all schemas via `gold_edition_v16.sql` (Core, CRM, Building, Accounting)
- Create default roles and departments
- Set up migration tracking

**Duration:** ~2-3 minutes

#### 4. Run Setup Wizard
```bash
sudo /opt/enterprise-os/scripts/setup-wizard.sh
```

Interactive wizard will configure:
- Company information
- Network settings
- Initial admin account
- Departments and VLANs
- Access control terminals
- Building automation devices
- Dashboard applications (Admin, Employee, HR, Finance, Executive)

**Duration:** ~5-10 minutes (depending on number of devices)

#### 5. Install Additional Dashboards (Optional)
```bash
# If you skipped during setup wizard, install later:
sudo /opt/enterprise-os/scripts/install-dashboards.sh
```

#### 6. Validate Installation
```bash
sudo /opt/enterprise-os/scripts/validate-installation.sh
```

Runs 15+ automated tests to verify:
- Service is running
- Database is accessible
- API endpoints respond
- Configuration is valid
- Security settings applied

**Duration:** ~1 minute

#### 6. Start the Service
```bash
sudo systemctl start enterprise-os
sudo systemctl status enterprise-os
```

### Post-Installation

1. **Access Web Interface**
   ```
   https://YOUR_SERVER_IP:8443
   ```

2. **Login with admin account created in wizard**

3. **Complete PKI Setup** (optional, for production)
   ```bash
   # See docs/PKI_SETUP.md for certificate generation
   ```

4. **Provision Client Workstations**
   ```bash
   # On each client machine:
   curl -k https://SERVER_IP:8443/downloads/provision-client.sh | sudo bash -s https://SERVER_IP:8443 DEPARTMENT_ID
   ```

---

## Alternative: Manual Installation

If you prefer manual control, see `docs/PRODUCTION_DEPLOYMENT.md` for step-by-step instructions.

---

## Available Scripts

| Script | Purpose | Usage |
|--------|---------|-------|
| `install-server.sh` | Automated server installation | `sudo ./install-server.sh` |
| `init-database.sh` | Database initialization | `sudo ./init-database.sh` |
| `setup-wizard.sh` | Interactive setup | `sudo ./setup-wizard.sh` |
| `validate-installation.sh` | System validation | `sudo ./validate-installation.sh` |
| `provision-client.sh` | Client provisioning | `./provision-client.sh SERVER_URL DEPT_ID` |
| `backup.sh` | Manual backup | `sudo /usr/local/bin/eos-backup` |
| `build-department-image.sh` | Build custom OS image | `./build-department-image.sh PROFILE_NAME` |

---

## Troubleshooting

### Installation fails
```bash
# Check logs
sudo journalctl -xe

# Verify dependencies
apt list --installed | grep -E 'postgresql|zmq|ssl'
```

### Database connection fails
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Test connection
sudo -u postgres psql -d enterprise_os -c '\q'
```

### Service won't start
```bash
# Check configuration
sudo cat /etc/enterprise-os/server.conf

# Check environment variables
sudo cat /etc/environment | grep EOS
```

### Web interface not accessible
```bash
# Check firewall
sudo ufw status

# Allow HTTPS
sudo ufw allow 8443/tcp
```

---

## Support

- **Documentation**: `/opt/enterprise-os/docs/`
- **Logs**: `/var/log/enterprise-os/`
- **Configuration**: `/etc/enterprise-os/`

---

## Next Steps

1. **Configure Access Terminals**
   - Register face recognition terminals
   - Upload employee photos
   - Test access control

2. **Set Up Building Automation**
   - Register doors and cameras
   - Configure HVAC zones
   - Test emergency systems

3. **Create Users**
   - Add employees to database
   - Assign departments and roles
   - Configure permissions

4. **Deploy Client Workstations**
   - Use provision-client.sh
   - Or set up PXE boot for automated deployment

5. **Monitor System**
   - Check dashboards
   - Review logs
   - Set up alerts
