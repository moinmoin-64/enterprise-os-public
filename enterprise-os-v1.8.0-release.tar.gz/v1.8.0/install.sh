#!/bin/bash
set -e

# Enterprise OS - Master Release Installer
# Installs Enterprise OS from the local release package

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}ERROR: Please run as root (sudo ./install.sh)${NC}"
    exit 1
fi

echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN}Enterprise OS - Installation Wizard${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""

# 1. Install Dependencies
echo -e "${YELLOW}[1/5] Installing system dependencies...${NC}"
apt-get update
apt-get install -y postgresql-client libzmq5 libssl3 libyaml-cpp0.8 libcurl4 || true
echo -e "${GREEN}✓ Dependencies installed${NC}"

# 2. Install Server Package
echo -e "\n${YELLOW}[2/5] Installing Enterprise Server...${NC}"
SERVER_DEB=$(find packages -name "eos-server_*.deb" | head -1)

if [ -z "$SERVER_DEB" ]; then
    echo -e "${RED}ERROR: Server package not found in packages/${NC}"
    exit 1
fi

echo "Found package: $SERVER_DEB"
dpkg -i "$SERVER_DEB" || apt-get install -f -y
echo -e "${GREEN}✓ Server installed${NC}"

# 3. Database Setup
echo -e "\n${YELLOW}[3/5] Initializing Database...${NC}"
if [ -f "scripts/init-database.sh" ]; then
    chmod +x scripts/init-database.sh
    ./scripts/init-database.sh
else
    echo -e "${RED}Warning: init-database.sh not found${NC}"
fi

# 4. Dashboard Installation (Optional)
echo -e "\n${YELLOW}[4/5] Install Dashboards? [y/N]${NC}"
read -r INSTALL_DASHBOARDS
if [[ "$INSTALL_DASHBOARDS" =~ ^[Yy]$ ]]; then
    echo "Installing all dashboards..."
    for deb in packages/eos-*-dashboard_*.deb; do
        [ -e "$deb" ] || continue
        echo "Installing $deb..."
        dpkg -i "$deb" || apt-get install -f -y
    done
    echo -e "${GREEN}✓ Dashboards installed${NC}"
fi

# 5. Start Services
echo -e "\n${YELLOW}[5/5] Starting Services...${NC}"
systemctl enable eos-server
systemctl restart eos-server
echo -e "${GREEN}✓ Service started${NC}"

echo ""
echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN}Installation Complete!${NC}"
echo -e "${GREEN}=========================================${NC}"
echo "Run 'sudo eos-server --activate <KEY>' to license your system."
