Enterprise OS v1.8.0 - Closed Source Release
================================================

This package contains COMPILED BINARIES ONLY.
Source code is proprietary and not included.

Contents:
---------
packages/       - Debian packages (.deb files)
schemas/        - Database schemas (.sql files)
scripts/        - Installation and setup scripts
docs/           - User and admin documentation
license-public.pem - License verification public key

Installation:
-------------
1. Run the automated installer:
   sudo ./install.sh

   This will automatically:
   - Install all system dependencies
   - Install the Server package
   - Initialize the database
   - Start the services

Manual Installation (Advanced):
-------------------------------
1. Run: sudo ./scripts/install-server.sh
2. Import schemas: sudo ./scripts/init-database.sh  
3. Setup: sudo ./scripts/setup-wizard.sh
4. Activate license: sudo eos-server --activate YOUR-LICENSE-KEY

Support:
--------
Email: support@yourcompany.com
Docs: https://docs.yourcompany.com

License:
--------
This software is proprietary and confidential.
Unauthorized copying, modification, or distribution is prohibited.
See LICENSE.txt for full terms.

(c) 2025 Your Company. All rights reserved.
