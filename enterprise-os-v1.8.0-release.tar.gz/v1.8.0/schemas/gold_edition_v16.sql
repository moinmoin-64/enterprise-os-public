-- Enterprise OS Gold Edition (v1.6.0) - Unified Master Schema
-- This file aggregates all individual module schemas in dependency order.

-- 1. Identity & Users (Base)
\i 01-users.sql

-- 2. Security & Immutable Auditing
-- Note: This requires the audit_trigger_func() defined in 08-audit-log.sql
\i 08-audit-log.sql

-- 3. ERP: CRM Module
\i 09-crm.sql

-- 4. ERP: Advanced Accounting
\i 10-accounting.sql

-- 5. Physical: Building Automation & IoT
\i 11-building.sql

-- 6. Service: Ticketing & Field Service
\i 12-ticketing.sql

-- Initial Seed Data (Optional/Demo)
-- INSERT INTO building_zones (zone_name, description) VALUES ('Headquarters', 'Main Office Building');
-- INSERT INTO accounting_periods (period_name, start_date, end_date) VALUES ('FY2025-Q1', '2025-01-01', '2025-03-31');
