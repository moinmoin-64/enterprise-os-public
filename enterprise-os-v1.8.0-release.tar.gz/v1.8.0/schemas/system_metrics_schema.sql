-- System metrics table for monitoring
CREATE TABLE IF NOT EXISTS system_metrics (
    metric_id SERIAL PRIMARY KEY,
    metric_name VARCHAR(100) NOT NULL,
    metric_value NUMERIC NOT NULL,
    recorded_at TIMESTAMP DEFAULT NOW(),
    INDEX idx_metrics_name (metric_name),
    INDEX idx_metrics_time (recorded_at DESC)
);

-- Insert sample system metrics
INSERT INTO system_metrics (metric_name, metric_value)
VALUES 
    ('cpu_usage', 45.2),
    ('ram_usage', 62.8),
    ('disk_usage', 73.5);

-- Function to update system metrics
CREATE OR REPLACE FUNCTION update_system_metric(
    p_metric_name VARCHAR,
    p_value NUMERIC
) RETURNS VOID AS $$
BEGIN
    INSERT INTO system_metrics (metric_name, metric_value, recorded_at)
    VALUES (p_metric_name, p_value, NOW());
    
    -- Keep only last 1000 entries per metric
    DELETE FROM system_metrics
    WHERE metric_id IN (
        SELECT metric_id
        FROM system_metrics
        WHERE metric_name = p_metric_name
        ORDER BY recorded_at DESC
        OFFSET 1000
    );
END;
$$ LANGUAGE plpgsql;
