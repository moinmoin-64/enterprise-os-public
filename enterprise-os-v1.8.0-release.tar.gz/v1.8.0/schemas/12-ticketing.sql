-- Enterprise OS Ticketing & Field Service Schema
CREATE TABLE IF NOT EXISTS tickets (
    ticket_id VARCHAR(50) PRIMARY KEY,
    subject VARCHAR(255) NOT NULL,
    description TEXT,
    created_by INTEGER REFERENCES users(user_id),
    assigned_technician_id INTEGER REFERENCES users(user_id),
    status VARCHAR(50) DEFAULT 'OPEN', -- 'OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'
    priority VARCHAR(20) DEFAULT 'MEDIUM',
    ai_category VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS work_orders (
    order_id SERIAL PRIMARY KEY,
    ticket_id VARCHAR(50) REFERENCES tickets(ticket_id),
    asset_tag VARCHAR(100), -- QR Code link to device
    location VARCHAR(255),
    instruction TEXT,
    completion_notes TEXT,
    completed_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mobile_devices (
    device_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    device_model VARCHAR(100),
    os_version VARCHAR(50),
    enrollment_token VARCHAR(255) UNIQUE,
    is_active BOOLEAN DEFAULT TRUE,
    authorized_at TIMESTAMP DEFAULT NOW()
);

-- Audit Triggers
CREATE TRIGGER ticket_audit_trg AFTER INSERT OR UPDATE OR DELETE ON tickets FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
CREATE TRIGGER mobile_audit_trg AFTER INSERT OR UPDATE OR DELETE ON mobile_devices FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
