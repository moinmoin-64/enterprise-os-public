-- CRM Module Database Schema
-- Customer Relationship Management Tables

-- Customers
CREATE TABLE IF NOT EXISTS customers (
    customer_id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    industry VARCHAR(100),
    annual_revenue DECIMAL(15,2),
    contact_person_id INTEGER,
    assigned_sales_rep INTEGER REFERENCES users(user_id),
    status VARCHAR(50) DEFAULT 'lead',  -- 'lead', 'prospect', 'customer', 'inactive'
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    custom_fields JSONB,
    CONSTRAINT valid_status CHECK (status IN ('lead', 'prospect', 'customer', 'inactive'))
);

-- Contacts
CREATE TABLE IF NOT EXISTS contacts (
    contact_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    position VARCHAR(100),
    customer_id INTEGER REFERENCES customers(customer_id) ON DELETE CASCADE,
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Sales Opportunities
CREATE TABLE IF NOT EXISTS opportunities (
    opportunity_id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(customer_id) ON DELETE CASCADE,
    title VARCHAR(512) NOT NULL,
    deal_value DECIMAL(12,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'EUR',
    probability_percent INTEGER CHECK (probability_percent BETWEEN 0 AND 100),
    expected_close_date DATE,
    stage VARCHAR(50) DEFAULT 'prospecting',
    assigned_to INTEGER REFERENCES users(user_id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    notes JSONB,
    CONSTRAINT valid_stage CHECK (stage IN ('prospecting', 'qualification', 'proposal', 
                                             'negotiation', 'closed_won', 'closed_lost'))
);

-- Leads
CREATE TABLE IF NOT EXISTS leads (
    lead_id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    contact_name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    source VARCHAR(100),  -- 'website', 'referral', 'cold_call', 'event', etc.
    status VARCHAR(50) DEFAULT 'new',
    assigned_to INTEGER REFERENCES users(user_id),
    estimated_value DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT NOW(),
    converted_to_customer_id INTEGER REFERENCES customers(customer_id),
    CONSTRAINT valid_lead_status CHECK (status IN ('new', 'contacted', 'qualified', 'converted', 'lost'))
);

-- Customer Contracts
CREATE TABLE IF NOT EXISTS customer_contracts (
    contract_id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(customer_id) ON DELETE CASCADE,
    contract_number VARCHAR(100) UNIQUE NOT NULL,
    contract_type VARCHAR(100),  -- 'service', 'product', 'subscription', etc.
    contract_value DECIMAL(12,2),
    start_date DATE NOT NULL,
    end_date DATE,
    status VARCHAR(50) DEFAULT 'draft',
    document_path VARCHAR(512),
    created_by INTEGER REFERENCES users(user_id),
    created_at TIMESTAMP DEFAULT NOW(),
    CONSTRAINT valid_contract_status CHECK (status IN ('draft', 'active', 'expired', 'terminated'))
);

-- Opportunity History (track stage changes)
CREATE TABLE IF NOT EXISTS opportunity_history (
    history_id SERIAL PRIMARY KEY,
    opportunity_id INTEGER REFERENCES opportunities(opportunity_id) ON DELETE CASCADE,
    previous_stage VARCHAR(50),
    new_stage VARCHAR(50),
    changed_by INTEGER REFERENCES users(user_id),
    changed_at TIMESTAMP DEFAULT NOW(),
    notes TEXT
);

-- Customer Interactions
CREATE TABLE IF NOT EXISTS customer_interactions (
    interaction_id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(customer_id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL,  -- 'call', 'email', 'meeting', 'demo', etc.
    subject VARCHAR(512),
    notes TEXT,
    interaction_date TIMESTAMP DEFAULT NOW(),
    created_by INTEGER REFERENCES users(user_id),
    opportunity_id INTEGER REFERENCES opportunities(opportunity_id)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_customers_sales_rep ON customers(assigned_sales_rep);
CREATE INDEX IF NOT EXISTS idx_customers_status ON customers(status);
CREATE INDEX IF NOT EXISTS idx_opportunities_stage ON opportunities(stage);
CREATE INDEX IF NOT EXISTS idx_opportunities_assigned ON opportunities(assigned_to);
CREATE INDEX IF NOT EXISTS idx_opportunities_customer ON opportunities(customer_id);
CREATE INDEX IF NOT EXISTS idx_leads_assigned ON leads(assigned_to);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_contacts_customer ON contacts(customer_id);
CREATE INDEX IF NOT EXISTS idx_contracts_customer ON customer_contracts(customer_id);
CREATE INDEX IF NOT EXISTS idx_interactions_customer ON customer_interactions(customer_id);

-- Views for analytics
CREATE OR REPLACE VIEW v_sales_pipeline AS
SELECT 
    o.opportunity_id,
    o.title,
    c.company_name,
    o.deal_value,
    o.probability_percent,
    (o.deal_value * o.probability_percent / 100.0) AS weighted_value,
    o.stage,
    o.expected_close_date,
    u.username AS sales_rep
FROM opportunities o
JOIN customers c ON o.customer_id = c.customer_id
LEFT JOIN users u ON o.assigned_to = u.user_id
WHERE o.stage NOT IN ('closed_won', 'closed_lost')
ORDER BY weighted_value DESC;

CREATE OR REPLACE VIEW v_customer_summary AS
SELECT 
    c.customer_id,
    c.company_name,
    c.industry,
    c.status,
    COUNT(DISTINCT o.opportunity_id) AS opportunity_count,
    COALESCE(SUM(o.deal_value) FILTER (WHERE o.stage = 'closed_won'), 0) AS total_won,
    COALESCE(SUM(o.deal_value) FILTER (WHERE o.stage NOT IN ('closed_won', 'closed_lost')), 0) AS pipeline,
    COUNT(DISTINCT cc.contract_id) AS contract_count,
    u.username AS sales_rep
FROM customers c
LEFT JOIN opportunities o ON c.customer_id = o.customer_id
LEFT JOIN customer_contracts cc ON c.customer_id = cc.customer_id
LEFT JOIN users u ON c.assigned_sales_rep = u.user_id
GROUP BY c.customer_id, c.company_name, c.industry, c.status, u.username;

-- Trigger to update customer.updated_at
CREATE OR REPLACE FUNCTION update_customer_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_customer_update
BEFORE UPDATE ON customers
FOR EACH ROW
EXECUTE FUNCTION update_customer_timestamp();

-- Trigger to log opportunity stage changes
CREATE OR REPLACE FUNCTION log_opportunity_stage_change()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.stage IS DISTINCT FROM NEW.stage THEN
        INSERT INTO opportunity_history (opportunity_id, previous_stage, new_stage)
        VALUES (NEW.opportunity_id, OLD.stage, NEW.stage);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_opportunity_stage_change
AFTER UPDATE ON opportunities
FOR EACH ROW
EXECUTE FUNCTION log_opportunity_stage_change();
