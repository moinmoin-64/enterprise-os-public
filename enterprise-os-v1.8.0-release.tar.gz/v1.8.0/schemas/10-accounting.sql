-- Enterprise OS Accounting Schema
CREATE TABLE IF NOT EXISTS accounts (
    account_code VARCHAR(20) PRIMARY KEY,
    account_name VARCHAR(255) NOT NULL,
    account_type VARCHAR(50) NOT NULL, -- 'asset', 'liability', 'equity', 'revenue', 'expense'
    normal_balance VARCHAR(10) NOT NULL, -- 'debit', 'credit'
    description TEXT
);

CREATE TABLE IF NOT EXISTS general_ledger (
    entry_id BIGSERIAL PRIMARY KEY,
    transaction_date DATE NOT NULL DEFAULT CURRENT_DATE,
    account_code VARCHAR(20) REFERENCES accounts(account_code),
    debit_amount DECIMAL(15,2) DEFAULT 0.00,
    credit_amount DECIMAL(15,2) DEFAULT 0.00,
    description TEXT,
    reference_id TEXT, -- e.g., 'INV-1002' or 'PAY-2023-12'
    created_by INTEGER REFERENCES users(user_id),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fiscal_periods (
    period_id SERIAL PRIMARY KEY,
    period_name VARCHAR(50) NOT NULL, -- e.g., 'Q4 2025'
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_closed BOOLEAN DEFAULT FALSE
);

-- Seed basic Chart of Accounts
INSERT INTO accounts (account_code, account_name, account_type, normal_balance) VALUES
('1000', 'Cash and Bank', 'asset', 'debit'),
('1200', 'Accounts Receivable', 'asset', 'debit'),
('2000', 'Accounts Payable', 'liability', 'credit'),
('3000', 'Retained Earnings', 'equity', 'credit'),
('4000', 'Sales Revenue', 'revenue', 'credit'),
('5000', 'Cost of Goods Sold', 'expense', 'debit'),
('6000', 'Salaries and Wages', 'expense', 'debit'),
('6100', 'Taxes Expense', 'expense', 'debit');

-- Audit Trigger
CREATE TRIGGER accounting_audit_trg AFTER INSERT OR UPDATE OR DELETE ON general_ledger FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
