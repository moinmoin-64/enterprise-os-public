-- IoT Building Integration Database Schema

-- Doors
CREATE TABLE IF NOT EXISTS doors (
    door_id SERIAL PRIMARY KEY,
    door_identifier VARCHAR(100) UNIQUE NOT NULL,
    location VARCHAR(255) NOT NULL,
    zone VARCHAR(100),
    is_locked BOOLEAN DEFAULT TRUE,
    linked_terminal_id INTEGER REFERENCES terminals(terminal_id),
    controller_ip INET NOT NULL,
    controller_type VARCHAR(50),  -- "http", "modbus", "bacnet"
    is_active BOOLEAN DEFAULT TRUE,
    last_state_change TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Door Events
CREATE TABLE IF NOT EXISTS door_events (
    event_id BIGSERIAL PRIMARY KEY,
    door_id INTEGER REFERENCES doors(door_id) ON DELETE CASCADE,
    event_type VARCHAR(50) NOT NULL,  -- "locked", "unlocked", "opened", "closed", "forced"
    triggered_by_user_id INTEGER REFERENCES users(user_id),
    timestamp TIMESTAMP DEFAULT NOW(),
    metadata JSONB
);

-- Cameras
CREATE TABLE IF NOT EXISTS cameras (
    camera_id SERIAL PRIMARY KEY,
    camera_identifier VARCHAR(100) UNIQUE NOT NULL,
    location VARCHAR(255) NOT NULL,
    zone VARCHAR(100),
    stream_url VARCHAR(512) NOT NULL,
    recording_path VARCHAR(512),
    is_recording BOOLEAN DEFAULT FALSE,
    motion_detection_enabled BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Camera Recordings
CREATE TABLE IF NOT EXISTS camera_recordings (
    recording_id BIGSERIAL PRIMARY KEY,
    camera_id INTEGER REFERENCES cameras(camera_id) ON DELETE CASCADE,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    file_path VARCHAR(512),
    file_size_bytes BIGINT,
    reason VARCHAR(255),  -- "access_event", "motion_detected", "manual", "emergency"
    related_event_id INTEGER,  -- Could be access_event_id, door_event_id, etc.
    is_archived BOOLEAN DEFAULT FALSE
);

-- HVAC Zones
CREATE TABLE IF NOT EXISTS hvac_zones (
    zone_id SERIAL PRIMARY KEY,
    zone_name VARCHAR(100) UNIQUE NOT NULL,
    controller_ip INET NOT NULL,
    current_temperature DECIMAL(5,2),
    target_temperature DECIMAL(5,2),
    mode VARCHAR(50) DEFAULT 'auto',  -- "auto", "heat", "cool", "off"
    fan_speed INTEGER CHECK (fan_speed BETWEEN 0 AND 100),
    is_active BOOLEAN DEFAULT TRUE,
    last_update TIMESTAMP DEFAULT NOW()
);

-- HVAC History
CREATE TABLE IF NOT EXISTS hvac_history (
    history_id BIGSERIAL PRIMARY KEY,
    zone_id INTEGER REFERENCES hvac_zones(zone_id) ON DELETE CASCADE,
    timestamp TIMESTAMP DEFAULT NOW(),
    temperature DECIMAL(5,2),
    humidity DECIMAL(5,2),
    mode VARCHAR(50),
    energy_consumption_kwh DECIMAL(10,3)
) PARTITION BY RANGE (timestamp);

-- Emergency Events
CREATE TABLE IF NOT EXISTS emergency_events (
    event_id SERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,  -- "fire", "evacuation", "lockdown", "medical"
    triggered_by_user_id INTEGER REFERENCES users(user_id),
    triggered_at TIMESTAMP DEFAULT NOW(),
    resolved_at TIMESTAMP,
    resolved_by_user_id INTEGER REFERENCES users(user_id),
    affected_zones TEXT[],
    response_actions JSONB,
    notes TEXT
);

-- Building Schedules
CREATE TABLE IF NOT EXISTS building_schedules (
    schedule_id SERIAL PRIMARY KEY,
    schedule_name VARCHAR(255) UNIQUE NOT NULL,
    schedule_type VARCHAR(50) NOT NULL,  -- "door", "hvac", "lighting"
    target_zones TEXT[],
    schedule_data JSONB NOT NULL,  -- Contains cron-like schedule rules
    is_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_door_events_door ON door_events(door_id);
CREATE INDEX IF NOT EXISTS idx_door_events_timestamp ON door_events(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_doors_zone ON doors(zone);
CREATE INDEX IF NOT EXISTS idx_cameras_zone ON cameras(zone);
CREATE INDEX IF NOT EXISTS idx_camera_recordings_camera ON camera_recordings(camera_id);
CREATE INDEX IF NOT EXISTS idx_camera_recordings_time ON camera_recordings(start_time DESC);
CREATE INDEX IF NOT EXISTS idx_hvac_zones_active ON hvac_zones(is_active);
CREATE INDEX IF NOT EXISTS idx_emergency_events_type ON emergency_events(event_type);

-- Views
CREATE OR REPLACE VIEW v_building_status AS
SELECT
    (SELECT COUNT(*) FROM doors WHERE is_active = true) AS total_doors,
    (SELECT COUNT(*) FROM doors WHERE is_locked = true AND is_active = true) AS locked_doors,
    (SELECT COUNT(*) FROM cameras WHERE is_active = true) AS total_cameras,
    (SELECT COUNT(*) FROM cameras WHERE is_recording = true) AS recording_cameras,
    (SELECT COUNT(*) FROM hvac_zones WHERE is_active = true) AS total_hvac_zones,
    (SELECT AVG(current_temperature) FROM hvac_zones WHERE is_active = true) AS avg_temperature,
    (SELECT COUNT(*) FROM emergency_events WHERE resolved_at IS NULL) AS active_emergencies;

-- Triggers
CREATE OR REPLACE FUNCTION update_door_state_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.is_locked IS DISTINCT FROM NEW.is_locked THEN
        NEW.last_state_change = NOW();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_door_state_update
BEFORE UPDATE ON doors
FOR EACH ROW
EXECUTE FUNCTION update_door_state_timestamp();

-- Automatic camera recording archival (move old recordings)
CREATE OR REPLACE FUNCTION archive_old_recordings()
RETURNS void AS $$
BEGIN
    UPDATE camera_recordings
    SET is_archived = TRUE
    WHERE end_time < NOW() - INTERVAL '30 days'
      AND is_archived = FALSE;
END;
$$ LANGUAGE plpgsql;
