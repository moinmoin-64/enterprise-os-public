-- Enterprise OS - Extended Deployment Schema
-- Tables for Bridge Service and Homeoffice Management

BEGIN;

-- Bridge Sessions Tracking
CREATE TABLE IF NOT EXISTS bridge_sessions (
    session_id VARCHAR(100) PRIMARY KEY,
    admin_user_id INTEGER REFERENCES users(user_id),
    target_device_id INTEGER REFERENCES devices(device_id),
    target_mac_address VARCHAR(20),
    image_id VARCHAR(100),
    status VARCHAR(50) DEFAULT 'initiated',
    progress_percent INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    error_message TEXT
);

-- Homeoffice Device Registration
CREATE TABLE IF NOT EXISTS homeoffice_devices (
    device_id SERIAL PRIMARY KEY,
    device_mac VARCHAR(20) UNIQUE NOT NULL,
    device_model VARCHAR(255),
    issued_to_user_id INTEGER REFERENCES users(user_id),
    issued_date DATE DEFAULT CURRENT_DATE,
    is_active BOOLEAN DEFAULT TRUE,
    last_seen TIMESTAMP,
    metadata JSONB
);

-- Homeoffice Sessions
CREATE TABLE IF NOT EXISTS homeoffice_sessions (
    session_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    device_mac VARCHAR(20),
    distro_partition INTEGER,
    ip_address INET,
    login_time TIMESTAMP DEFAULT NOW(),
    logout_time TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSONB
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_bridge_sessions_admin ON bridge_sessions(admin_user_id);
CREATE INDEX IF NOT EXISTS idx_homeoffice_devices_user ON homeoffice_devices(issued_to_user_id);
CREATE INDEX IF NOT EXISTS idx_homeoffice_sessions_user ON homeoffice_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_homeoffice_sessions_active ON homeoffice_sessions(is_active) WHERE is_active = TRUE;

COMMIT;
