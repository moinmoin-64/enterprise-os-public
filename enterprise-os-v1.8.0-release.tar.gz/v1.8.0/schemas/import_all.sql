-- Complete Schema Import Script
-- Run this to import all schemas in the correct order

BEGIN;

-- Import core schema
\i schema/full_schema.sql

-- Import CRM schema
\i schema/crm_schema.sql

-- Import Building IoT schema
\i schema/building_iot_schema.sql

-- Import Terminal Updates schema
\i schema/terminal_updates_schema.sql

-- Import System Metrics schema
\i schema/system_metrics_schema.sql

-- Import Software Updates schema
\i schema/software_updates_schema.sql

-- Import Licensing schema
\i schema/licensing_schema.sql

-- Verify all tables
DO $$
DECLARE
    table_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO table_count 
    FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE';
    
    RAISE NOTICE 'Total tables created: %', table_count;
    
    IF table_count < 50 THEN
        RAISE EXCEPTION 'Expected at least 50 tables, got %', table_count;
    END IF;
END $$;

COMMIT;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_access_logs_user ON access_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_access_logs_terminal ON access_logs(terminal_id);
CREATE INDEX IF NOT EXISTS idx_access_logs_timestamp ON access_logs(access_time DESC);
CREATE INDEX IF NOT EXISTS idx_devices_owner ON devices(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_tickets_requester ON tickets(requester_user_id);
CREATE INDEX IF NOT EXISTS idx_security_alerts_time ON security_alerts(detected_at DESC);

-- Additional indexes for new schemas
CREATE INDEX IF NOT EXISTS idx_licenses_key ON licenses(license_key);
CREATE INDEX IF NOT EXISTS idx_licenses_customer ON licenses(customer_id);
CREATE INDEX IF NOT EXISTS idx_device_updates_device ON device_updates(device_id);
CREATE INDEX IF NOT EXISTS idx_device_updates_version ON device_updates(version_id);

-- Analyze tables
ANALYZE;

SELECT 'Schema import complete!' as status;

