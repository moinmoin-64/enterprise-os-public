-- Software Update Tracking Schema

-- Update channels
CREATE TABLE update_channels (
    channel_id SERIAL PRIMARY KEY,
    channel_name VARCHAR(20) UNIQUE NOT NULL,  -- stable, beta, dev
    description TEXT,
    auto_deploy BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO update_channels (channel_name, description, auto_deploy) VALUES
('stable', 'Production-ready updates', true),
('beta', 'Pre-release testing updates', false),
('dev', 'Development updates', false);

-- Software packages/versions
CREATE TABLE software_versions (
    version_id SERIAL PRIMARY KEY,
    component_name VARCHAR(100) NOT NULL,  -- server, admin-dashboard, terminal, etc.
    version_number VARCHAR(20) NOT NULL,
    channel_id INT REFERENCES update_channels(channel_id),
    release_date TIMESTAMP DEFAULT NOW(),
    changelog TEXT,
    package_size BIGINT,  -- bytes
    checksum_sha256 VARCHAR(64),
    download_url TEXT,
    is_critical BOOLEAN DEFAULT false,
    is_security_fix BOOLEAN DEFAULT false,
    rollout_percentage INT DEFAULT 100,  -- For staged rollouts
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(component_name, version_number, channel_id)
);

CREATE INDEX idx_software_versions_component ON software_versions(component_name);
CREATE INDEX idx_software_versions_channel ON software_versions(channel_id);

-- Device update status
CREATE TABLE device_updates (
    update_id SERIAL PRIMARY KEY,
    device_id INT REFERENCES devices(device_id),
    version_id INT REFERENCES software_versions(version_id),
    status VARCHAR(20) NOT NULL,  -- pending, downloading, installing, completed, failed, rolled_back
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    download_progress INT DEFAULT 0,  -- 0-100
    install_duration INT,  -- seconds
    previous_version VARCHAR(20),
    rollback_available BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_device_updates_device ON device_updates(device_id);
CREATE INDEX idx_device_updates_status ON device_updates(status);
CREATE INDEX idx_device_updates_version ON device_updates(version_id);

-- Update analytics
CREATE TABLE update_analytics (
    analytics_id SERIAL PRIMARY KEY,
    version_id INT REFERENCES software_versions(version_id),
    total_devices INT DEFAULT 0,
    successful_updates INT DEFAULT 0,
    failed_updates INT DEFAULT 0,
    average_install_time INT,  -- seconds
    success_rate DECIMAL(5,2),  -- percentage
    last_updated TIMESTAMP DEFAULT NOW()
);

-- Update notifications (for admins)
CREATE TABLE update_notifications (
    notification_id SERIAL PRIMARY KEY,
    version_id INT REFERENCES software_versions(version_id),
    notification_type VARCHAR(20),  -- new_update, critical_update, rollout_complete
    message TEXT,
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    read_at TIMESTAMP
);

-- View: Current device versions
CREATE VIEW v_device_current_versions AS
SELECT 
    d.device_id,
    d.device_identifier,
    d.device_type,
    du.component_name,
    du.current_version,
    sv.version_number AS latest_version,
    sv.version_id AS latest_version_id,
    CASE 
        WHEN du.current_version = sv.version_number THEN 'up_to_date'
        WHEN du.current_version IS NULL THEN 'unknown'
        ELSE 'update_available'
    END AS update_status
FROM devices d
LEFT JOIN LATERAL (
    SELECT DISTINCT ON (component_name)
        component_name,
        previous_version AS current_version
    FROM device_updates
    WHERE device_id = d.device_id AND status = 'completed'
    ORDER BY component_name, completed_at DESC
) du ON true
LEFT JOIN LATERAL (
    SELECT version_id, component_name, version_number
    FROM software_versions
    WHERE component_name = du.component_name
      AND channel_id = (SELECT channel_id FROM update_channels WHERE channel_name = 'stable')
    ORDER BY release_date DESC
    LIMIT 1
) sv ON true;

-- View: Update statistics
CREATE VIEW v_update_statistics AS
SELECT 
    sv.component_name,
    sv.version_number,
    uc.channel_name,
    COUNT(du.update_id) AS total_attempts,
    COUNT(CASE WHEN du.status = 'completed' THEN 1 END) AS successful,
    COUNT(CASE WHEN du.status = 'failed' THEN 1 END) AS failed,
    ROUND(AVG(du.install_duration)) AS avg_install_time_seconds,
    ROUND(COUNT(CASE WHEN du.status = 'completed' THEN 1 END)::NUMERIC / 
          NULLIF(COUNT(du.update_id), 0) * 100, 2) AS success_rate
FROM software_versions sv
LEFT JOIN device_updates du ON sv.version_id = du.version_id
LEFT JOIN update_channels uc ON sv.channel_id = uc.channel_id
GROUP BY sv.component_name, sv.version_number, uc.channel_name;

-- Function: Check for updates for a device
CREATE OR REPLACE FUNCTION get_available_updates(p_device_id INT)
RETURNS TABLE (
    component_name VARCHAR,
    current_version VARCHAR,
    latest_version VARCHAR,
    changelog TEXT,
    is_critical BOOLEAN,
    package_size BIGINT,
    download_url TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        vcv.component_name,
        vcv.current_version,
        sv.version_number AS latest_version,
        sv.changelog,
        sv.is_critical,
        sv.package_size,
        sv.download_url
    FROM v_device_current_versions vcv
    JOIN software_versions sv ON vcv.latest_version_id = sv.version_id
    WHERE vcv.device_id = p_device_id
      AND vcv.update_status = 'update_available';
END;
$$ LANGUAGE plpgsql;

-- Function: Record update attempt
CREATE OR REPLACE FUNCTION record_update_attempt(
    p_device_id INT,
    p_version_id INT,
    p_previous_version VARCHAR
) RETURNS INT AS $$
DECLARE
    v_update_id INT;
BEGIN
    INSERT INTO device_updates (device_id, version_id, status, started_at, previous_version)
    VALUES (p_device_id, p_version_id, 'downloading', NOW(), p_previous_version)
    RETURNING update_id INTO v_update_id;
    
    RETURN v_update_id;
END;
$$ LANGUAGE plpgsql;

-- Function: Update installation status
CREATE OR REPLACE FUNCTION update_installation_status(
    p_update_id INT,
    p_status VARCHAR,
    p_error_message TEXT DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
    UPDATE device_updates
    SET status = p_status,
        completed_at = CASE WHEN p_status IN ('completed', 'failed', 'rolled_back') 
                            THEN NOW() ELSE completed_at END,
        error_message = p_error_message,
        install_duration = CASE WHEN p_status = 'completed'
                               THEN EXTRACT(EPOCH FROM (NOW() - started_at))::INT
                               ELSE install_duration END
    WHERE update_id = p_update_id;
    
    -- Update analytics
    IF p_status IN ('completed', 'failed') THEN
        INSERT INTO update_analytics (version_id, total_devices, successful_updates, failed_updates)
        SELECT 
            version_id,
            COUNT(*),
            COUNT(CASE WHEN status = 'completed' THEN 1 END),
            COUNT(CASE WHEN status = 'failed' THEN 1 END)
        FROM device_updates
        WHERE version_id = (SELECT version_id FROM device_updates WHERE update_id = p_update_id)
        GROUP BY version_id
        ON CONFLICT (version_id) DO UPDATE
        SET total_devices = EXCLUDED.total_devices,
            successful_updates = EXCLUDED.successful_updates,
            failed_updates = EXCLUDED.failed_updates,
            last_updated = NOW();
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Trigger: Create notification on new version
CREATE OR REPLACE FUNCTION notify_new_version()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO update_notifications (version_id, notification_type, message)
    VALUES (
        NEW.version_id,
        CASE WHEN NEW.is_critical THEN 'critical_update' ELSE 'new_update' END,
        'New ' || NEW.component_name || ' version ' || NEW.version_number || ' available in ' ||
        (SELECT channel_name FROM update_channels WHERE channel_id = NEW.channel_id)
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_new_version_notification
AFTER INSERT ON software_versions
FOR EACH ROW
EXECUTE FUNCTION notify_new_version();

-- Sample data
INSERT INTO software_versions (component_name, version_number, channel_id, changelog, package_size, checksum_sha256, is_critical)
VALUES 
('server', '1.0.0', 1, 'Initial release', 52428800, 'abc123...', false),
('admin-dashboard', '1.0.0', 1, 'Initial release', 12582912, 'def456...', false),
('terminal', '1.0.0', 1, 'Initial release', 8388608, 'ghi789...', false);
