-- Enterprise OS Audit Schema (Blockchain-Linked)
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    table_name TEXT NOT NULL,
    action TEXT NOT NULL,
    row_id TEXT NOT NULL,
    old_data JSONB,
    new_data JSONB,
    changed_by TEXT,
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    blockchain_hash TEXT, -- SHA-256 of (id + prev_hash + content)
    previous_hash TEXT    -- Link to the previous block
);

-- Index for fast chain verification
CREATE INDEX IF NOT EXISTS idx_audit_blockchain ON audit_log(blockchain_hash);

CREATE OR REPLACE FUNCTION audit_trigger_func()
RETURNS TRIGGER AS $$
DECLARE
    prev_hash TEXT;
BEGIN
    -- Get the hash of the latest entry to link the chain
    SELECT blockchain_hash INTO prev_hash FROM audit_log ORDER BY id DESC LIMIT 1;
    IF prev_hash IS NULL THEN prev_hash := 'GENESIS_BLOCK'; END IF;

    IF (TG_OP = 'DELETE') THEN
        INSERT INTO audit_log (table_name, action, row_id, old_data, changed_by, previous_hash)
        VALUES (TG_TABLE_NAME, 'DELETE', OLD.id::text, row_to_json(OLD)::jsonb, current_user, prev_hash);
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_log (table_name, action, row_id, old_data, new_data, changed_by, previous_hash)
        VALUES (TG_TABLE_NAME, 'UPDATE', NEW.id::text, row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb, current_user, prev_hash);
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO audit_log (table_name, action, row_id, new_data, changed_by, previous_hash)
        VALUES (TG_TABLE_NAME, 'INSERT', NEW.id::text, row_to_json(NEW)::jsonb, current_user, prev_hash);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Automated Hash Generator (Simulated post-insert hook for Phase 13)
-- In a real blockchain, this would be computed by a secure enclave.
-- Here we use a trigger to mimic the immutable linking.
CREATE OR REPLACE FUNCTION compute_audit_hash()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE audit_log 
    SET blockchain_hash = encode(sha256((id::text || previous_hash || table_name || action || row_id)::bytea), 'hex')
    WHERE id = NEW.id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_compute_hash
AFTER INSERT ON audit_log
FOR EACH ROW EXECUTE FUNCTION compute_audit_hash();
