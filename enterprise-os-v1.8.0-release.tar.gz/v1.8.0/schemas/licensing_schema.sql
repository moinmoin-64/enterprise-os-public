-- License Management and Anti-Piracy Schema

-- License types/plans
CREATE TABLE license_types (
    license_type_id SERIAL PRIMARY KEY,
    type_name VARCHAR(50) UNIQUE NOT NULL,  -- starter, professional, enterprise, trial
    description TEXT,
    max_users INT,  -- -1 for unlimited
    max_devices INT,  -- -1 for unlimited
    max_terminals INT,
    features JSONB,  -- {"crm": true, "building_automation": false}
    monthly_price DECIMAL(10,2),
    yearly_price DECIMAL(10,2),
    trial_days INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO license_types (type_name, description, max_users, max_devices, max_terminals, features, monthly_price, yearly_price, trial_days) VALUES
('trial', 'Trial Version', 10, 5, 2, '{"all": true}', 0, 0, 30),
('starter', 'Starter Plan', 50, 25, 5, '{"basic": true}', 99.00, 999.00, 0),
('professional', 'Professional Plan', 200, 100, 20, '{"advanced": true, "crm": true}', 299.00, 2999.00, 0),
('enterprise', 'Enterprise Plan', -1, -1, -1, '{"all": true}', 999.00, 9999.00, 0);

-- Customer organizations
CREATE TABLE license_customers (
    customer_id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    contact_name VARCHAR(255),
    contact_email VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(50),
    billing_address TEXT,
    tax_id VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Licenses
CREATE TABLE licenses (
    license_id SERIAL PRIMARY KEY,
    license_key VARCHAR(100) UNIQUE NOT NULL,  -- Format: XXXX-XXXX-XXXX-XXXX-XXXX
    customer_id INT REFERENCES license_customers(customer_id),
    license_type_id INT REFERENCES license_types(license_type_id),
    issued_date TIMESTAMP DEFAULT NOW(),
    activation_date TIMESTAMP,
    expiration_date TIMESTAMP,  -- NULL for perpetual
    is_active BOOLEAN DEFAULT true,
    is_trial BOOLEAN DEFAULT false,
    hardware_fingerprint VARCHAR(64),  -- SHA-256 hash of hardware ID
    organization_id VARCHAR(100),  -- Unique org identifier
    max_activations INT DEFAULT 1,
    current_activations INT DEFAULT 0,
    signature TEXT,  -- RSA signature for verification
    metadata JSONB,  -- Additional license metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_licenses_key ON licenses(license_key);
CREATE INDEX idx_licenses_customer ON licenses(customer_id);
CREATE INDEX idx_licenses_active ON licenses(is_active);

-- License activations (tracks each installation)
CREATE TABLE license_activations (
    activation_id SERIAL PRIMARY KEY,
    license_id INT REFERENCES licenses(license_id),
    device_id INT REFERENCES devices(device_id),
    hardware_fingerprint VARCHAR(64) NOT NULL,
    ip_address INET,
    hostname VARCHAR(255),
    activated_at TIMESTAMP DEFAULT NOW(),
    last_validated TIMESTAMP DEFAULT NOW(),
    validation_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    deactivated_at TIMESTAMP,
    deactivation_reason TEXT
);

CREATE INDEX idx_activations_license ON license_activations(license_id);
CREATE INDEX idx_activations_device ON license_activations(device_id);
CREATE INDEX idx_activations_fingerprint ON license_activations(hardware_fingerprint);

-- License validation log (audit trail)
CREATE TABLE license_validation_log (
    log_id SERIAL PRIMARY KEY,
    license_id INT REFERENCES licenses(license_id),
    activation_id INT REFERENCES license_activations(activation_id),
    validation_type VARCHAR(50),  -- online, offline, certificate
    success BOOLEAN,
    failure_reason TEXT,
    validated_at TIMESTAMP DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT
);

-- Tamper detection log
CREATE TABLE tamper_detection_log (
    tamper_id SERIAL PRIMARY KEY,
    license_id INT REFERENCES licenses(license_id),
    device_id INT REFERENCES devices(device_id),
    tamper_type VARCHAR(50),  -- binary_modified, license_file_altered, debugger_detected
    severity VARCHAR(20),  -- low, medium, high, critical
    details TEXT,
    detected_at TIMESTAMP DEFAULT NOW(),
    blocked BOOLEAN DEFAULT false
);

-- Feature flags (enable/disable features based on license)
CREATE TABLE license_feature_flags (
    flag_id SERIAL PRIMARY KEY,
    license_id INT REFERENCES licenses(license_id),
    feature_name VARCHAR(100) NOT NULL,
    is_enabled BOOLEAN DEFAULT true,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- View: Active licenses with customer info
CREATE VIEW v_active_licenses AS
SELECT 
    l.license_id,
    l.license_key,
    lc.company_name,
    lc.contact_email,
    lt.type_name AS license_type,
    l.issued_date,
    l.activation_date,
    l.expiration_date,
    l.is_trial,
    l.current_activations,
    l.max_activations,
    CASE 
        WHEN l.expiration_date IS NULL THEN 'perpetual'
        WHEN l.expiration_date < NOW() THEN 'expired'
        WHEN l.expiration_date > NOW() THEN 'active'
    END AS status,
    CASE
        WHEN l.expiration_date IS NOT NULL 
        THEN EXTRACT(DAY FROM (l.expiration_date - NOW()))
        ELSE NULL
    END AS days_remaining
FROM licenses l
JOIN license_customers lc ON l.customer_id = lc.customer_id
JOIN license_types lt ON l.license_type_id = lt.license_type_id
WHERE l.is_active = true;

-- Function: Generate license key
CREATE OR REPLACE FUNCTION generate_license_key()
RETURNS VARCHAR AS $$
DECLARE
    chars TEXT := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';  -- Exclude confusing chars
    result TEXT := '';
    i INT;
    segment TEXT;
BEGIN
    FOR i IN 1..5 LOOP
        segment := '';
        FOR j IN 1..4 LOOP
            segment := segment || substr(chars, floor(random() * length(chars) + 1)::int, 1);
        END LOOP;
        
        IF i > 1 THEN
            result := result || '-';
        END IF;
        result := result || segment;
    END LOOP;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function: Create new license
CREATE OR REPLACE FUNCTION create_license(
    p_customer_id INT,
    p_license_type_id INT,
    p_is_trial BOOLEAN DEFAULT false,
    p_duration_months INT DEFAULT NULL
) RETURNS VARCHAR AS $$
DECLARE
    v_license_key VARCHAR;
    v_expiration_date TIMESTAMP;
    v_max_activations INT;
BEGIN
    -- Generate unique license key
    LOOP
        v_license_key := generate_license_key();
        EXIT WHEN NOT EXISTS (SELECT 1 FROM licenses WHERE license_key = v_license_key);
    END LOOP;
    
    -- Calculate expiration date
    IF p_duration_months IS NOT NULL THEN
        v_expiration_date := NOW() + (p_duration_months || ' months')::INTERVAL;
    ELSIF p_is_trial THEN
        v_expiration_date := NOW() + (SELECT trial_days FROM license_types WHERE license_type_id = p_license_type_id) || ' days'::INTERVAL;
    ELSE
        v_expiration_date := NULL;  -- Perpetual
    END IF;
    
    -- Get max activations from license type
    SELECT CASE 
        WHEN max_devices = -1 THEN 999999 
        ELSE max_devices 
    END INTO v_max_activations
    FROM license_types WHERE license_type_id = p_license_type_id;
    
    -- Insert license
    INSERT INTO licenses (
        license_key, customer_id, license_type_id, 
        expiration_date, is_trial, max_activations
    ) VALUES (
        v_license_key, p_customer_id, p_license_type_id, 
        v_expiration_date, p_is_trial, v_max_activations
    );
    
    RETURN v_license_key;
END;
$$ LANGUAGE plpgsql;

-- Function: Validate license
CREATE OR REPLACE FUNCTION validate_license(
    p_license_key VARCHAR,
    p_hardware_fingerprint VARCHAR
) RETURNS TABLE (
    valid BOOLEAN,
    license_id INT,
    license_type VARCHAR,
    expiration_date TIMESTAMP,
    features JSONB,
    message TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        CASE 
            WHEN l.is_active = false THEN false
            WHEN l.expiration_date IS NOT NULL AND l.expiration_date < NOW() THEN false
            WHEN l.current_activations >= l.max_activations 
                 AND l.hardware_fingerprint IS DISTINCT FROM p_hardware_fingerprint THEN false
            ELSE true
        END AS valid,
        l.license_id,
        lt.type_name,
        l.expiration_date,
        lt.features,
        CASE 
            WHEN l.is_active = false THEN 'License deactivated'
            WHEN l.expiration_date IS NOT NULL AND l.expiration_date < NOW() THEN 'License expired'
            WHEN l.current_activations >= l.max_activations 
                 AND l.hardware_fingerprint IS DISTINCT FROM p_hardware_fingerprint 
                 THEN 'Maximum activations reached'
            ELSE 'License valid'
        END AS message
    FROM licenses l
    JOIN license_types lt ON l.license_type_id = lt.license_type_id
    WHERE l.license_key = p_license_key;
END;
$$ LANGUAGE plpgsql;

-- Function: Activate license
CREATE OR REPLACE FUNCTION activate_license(
    p_license_key VARCHAR,
    p_hardware_fingerprint VARCHAR,
    p_device_id INT,
    p_ip_address INET,
    p_hostname VARCHAR
) RETURNS TABLE (
    success BOOLEAN,
    activation_id INT,
    message TEXT
) AS $$
DECLARE
    v_license_id INT;
    v_is_valid BOOLEAN;
    v_activation_id INT;
    v_message TEXT;
BEGIN
    -- Validate license
    SELECT valid, license_id, validate_license.message 
    INTO v_is_valid, v_license_id, v_message
    FROM validate_license(p_license_key, p_hardware_fingerprint);
    
    IF NOT v_is_valid THEN
        RETURN QUERY SELECT false, NULL::INT, v_message;
        RETURN;
    END IF;
    
    -- Check if already activated on this hardware
    SELECT activation_activations.activation_id INTO v_activation_id
    FROM license_activations activation_activations
    WHERE activation_activations.license_id = v_license_id 
    AND activation_activations.hardware_fingerprint = p_hardware_fingerprint
    AND activation_activations.is_active = true;
    
    IF v_activation_id IS NOT NULL THEN
        -- Already activated, update last validated
        UPDATE license_activations 
        SET last_validated = NOW(), 
            validation_count = validation_count + 1
        WHERE activation_id = v_activation_id;
        
        RETURN QUERY SELECT true, v_activation_id, 'License re-validated'::TEXT;
        RETURN;
    END IF;
    
    -- Create new activation
    INSERT INTO license_activations (
        license_id, device_id, hardware_fingerprint, 
        ip_address, hostname
    ) VALUES (
        v_license_id, p_device_id, p_hardware_fingerprint,
        p_ip_address, p_hostname
    ) RETURNING license_activations.activation_id INTO v_activation_id;
    
    -- Update license
    UPDATE licenses 
    SET current_activations = current_activations + 1,
        activation_date = COALESCE(activation_date, NOW()),
        hardware_fingerprint = COALESCE(hardware_fingerprint, p_hardware_fingerprint)
    WHERE license_id = v_license_id;
    
    RETURN QUERY SELECT true, v_activation_id, 'License activated successfully'::TEXT;
END;
$$ LANGUAGE plpgsql;

-- Trigger: Log all validation attempts
CREATE OR REPLACE FUNCTION log_license_validation()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO license_validation_log (
        license_id, activation_id, validation_type, success, validated_at
    ) VALUES (
        NEW.license_id, NEW.activation_id, 'activation', true, NOW()
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_log_activation
AFTER INSERT ON license_activations
FOR EACH ROW
EXECUTE FUNCTION log_license_validation();

-- Sample data
INSERT INTO license_customers (company_name, contact_name, contact_email, contact_phone)
VALUES ('Acme Corporation', 'John Doe', 'admin@acme.com', '+1-555-0100');

-- Create a sample enterprise license
SELECT create_license(1, 4, false, NULL);  -- Perpetual enterprise license
