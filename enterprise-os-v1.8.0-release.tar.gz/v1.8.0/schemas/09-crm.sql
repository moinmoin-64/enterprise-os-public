-- Enterprise OS CRM Schema
CREATE TABLE IF NOT EXISTS customers (
    customer_id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    industry VARCHAR(100),
    annual_revenue DECIMAL(15,2),
    status VARCHAR(50) DEFAULT 'prospect', -- 'lead', 'prospect', 'active', 'churned'
    assigned_rep_id INTEGER REFERENCES users(user_id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS leads (
    lead_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(50),
    source VARCHAR(100), -- 'web', 'referral', 'exhibition'
    score INTEGER DEFAULT 0,
    customer_id INTEGER REFERENCES customers(customer_id),
    status VARCHAR(50) DEFAULT 'new'
);

CREATE TABLE IF NOT EXISTS opportunities (
    opportunity_id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(customer_id),
    opportunity_name VARCHAR(255) NOT NULL,
    expected_value DECIMAL(12,2),
    probability INTEGER CHECK (probability >= 0 AND probability <= 100),
    stage VARCHAR(50), -- 'discovery', 'proposal', 'negotiation', 'closed_won', 'closed_lost'
    expected_close_date DATE,
    assigned_to INTEGER REFERENCES users(user_id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Triggers for auditing CRM actions
CREATE TRIGGER customer_audit_trg AFTER INSERT OR UPDATE OR DELETE ON customers FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
CREATE TRIGGER opportunity_audit_trg AFTER INSERT OR UPDATE OR DELETE ON opportunities FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
