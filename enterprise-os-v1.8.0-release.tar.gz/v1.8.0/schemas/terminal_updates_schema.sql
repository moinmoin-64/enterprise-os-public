-- Terminal Software Update Tracking

CREATE TABLE IF NOT EXISTS terminal_updates (
    update_id SERIAL PRIMARY KEY,
    terminal_id INTEGER REFERENCES terminals(terminal_id) ON DELETE CASCADE,
    update_type VARCHAR(50) NOT NULL,  -- 'install', 'update', 'rollback'
    current_version VARCHAR(50),
    target_version VARCHAR(50) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',  -- 'pending', 'in_progress', 'completed', 'failed'
    initiated_at TIMESTAMP DEFAULT NOW(),
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    initiated_by_user_id INTEGER REFERENCES users(user_id),
    CONSTRAINT valid_update_status CHECK (status IN ('pending', 'in_progress', 'completed', 'failed', 'cancelled'))
);

-- Add software_version column to terminals table
ALTER TABLE terminals ADD COLUMN IF NOT EXISTS software_version VARCHAR(50);
ALTER TABLE terminals ADD COLUMN IF NOT EXISTS last_version_check TIMESTAMP;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_terminal_updates_terminal ON terminal_updates(terminal_id);
CREATE INDEX IF NOT EXISTS idx_terminal_updates_status ON terminal_updates(status);
CREATE INDEX IF NOT EXISTS idx_terminal_updates_initiated ON terminal_updates(initiated_at DESC);

-- View for terminal status including software version
CREATE OR REPLACE VIEW v_terminal_status AS
SELECT 
    t.terminal_id,
    t.terminal_identifier,
    t.location,
    t.terminal_type,
    t.ip_address,
    t.software_version,
    t.last_version_check,
    t.is_active,
    tu.update_id,
    tu.status AS update_status,
    tu.target_version AS update_target_version,
    tu.initiated_at AS update_initiated_at
FROM terminals t
LEFT JOIN LATERAL (
    SELECT *
    FROM terminal_updates
    WHERE terminal_id = t.terminal_id
    ORDER BY initiated_at DESC
    LIMIT 1
) tu ON true;

-- Function to check for outdated terminals
CREATE OR REPLACE FUNCTION get_outdated_terminals(current_version VARCHAR)
RETURNS TABLE (
    terminal_id INTEGER,
    terminal_identifier VARCHAR,
    software_version VARCHAR,
    location VARCHAR
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.terminal_id,
        t.terminal_identifier,
        t.software_version,
        t.location
    FROM terminals t
    WHERE t.is_active = true
    AND (t.software_version IS NULL OR t.software_version != current_version);
END;
$$ LANGUAGE plpgsql;
