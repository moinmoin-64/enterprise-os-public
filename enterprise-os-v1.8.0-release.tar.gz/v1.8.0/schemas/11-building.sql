-- Enterprise OS Building Automation Schema
CREATE TABLE IF NOT EXISTS building_zones (
    zone_id SERIAL PRIMARY KEY,
    zone_name VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS doors (
    door_id SERIAL PRIMARY KEY,
    door_identifier VARCHAR(100) UNIQUE NOT NULL,
    location VARCHAR(255),
    zone_id INTEGER REFERENCES building_zones(zone_id),
    is_locked BOOLEAN DEFAULT TRUE,
    linked_terminal_id INTEGER, -- Link to terminal for access-based unlock
    controller_ip VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    last_state_change TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS door_events (
    event_id BIGSERIAL PRIMARY KEY,
    door_id INTEGER REFERENCES doors(door_id),
    event_type VARCHAR(50), -- 'locked', 'unlocked', 'forced_open'
    triggered_by_user_id INTEGER,
    timestamp TIMESTAMP DEFAULT NOW(),
    metadata JSONB
);

CREATE TABLE IF NOT EXISTS cameras (
    camera_id SERIAL PRIMARY KEY,
    camera_identifier VARCHAR(100) UNIQUE NOT NULL,
    location VARCHAR(255),
    zone_id INTEGER REFERENCES building_zones(zone_id),
    stream_url VARCHAR(255),
    is_recording BOOLEAN DEFAULT FALSE,
    motion_detection_enabled BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS hvac_zones (
    hvac_id SERIAL PRIMARY KEY,
    zone_id INTEGER REFERENCES building_zones(zone_id),
    current_temperature DECIMAL(4,2),
    target_temperature DECIMAL(4,2) DEFAULT 21.0,
    mode VARCHAR(50) DEFAULT 'auto', -- 'heating', 'cooling', 'fan', 'eco'
    last_update TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS lighting_zones (
    light_id SERIAL PRIMARY KEY,
    zone_id INTEGER REFERENCES building_zones(zone_id),
    is_on BOOLEAN DEFAULT FALSE,
    brightness_percent INTEGER DEFAULT 100,
    is_eco_mode BOOLEAN DEFAULT TRUE
);

-- Audit Trigger for all building components
CREATE TRIGGER door_audit_trg AFTER INSERT OR UPDATE OR DELETE ON doors FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
CREATE TRIGGER hvac_audit_trg AFTER INSERT OR UPDATE OR DELETE ON hvac_zones FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
CREATE TRIGGER light_audit_trg AFTER INSERT OR UPDATE OR DELETE ON lighting_zones FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();
