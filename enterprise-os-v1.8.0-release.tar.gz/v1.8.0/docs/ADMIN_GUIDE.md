# Enterprise OS - System Administrator Guide

## Table of Contents
1. [Installation](#installation)
2. [Configuration](#configuration)
3. [Database Setup](#database-setup)
4. [Security Hardening](#security-hardening)
5. [Backup & Recovery](#backup--recovery)
6. [Monitoring](#monitoring)
7. [Troubleshooting](#troubleshooting)

## Installation

### Prerequisites
- Ubuntu 22.04 LTS or RHEL 8+
- PostgreSQL 14+
- ZeroMQ 4.3+
- OpenSSL 3.0+
- CMake 3.20+
- GCC 11+ or Clang 14+

### Build from Source

```bash
# Install dependencies
sudo apt-get update
sudo apt-get install -y \
    build-essential cmake git \
    libpq-dev libzmq3-dev libssl-dev \
    nlohmann-json3-dev libspdlog-dev

# Clone repository
cd /opt
sudo git clone https://github.com/enterprise/enterprise-os.git
cd enterprise-os

# Build
mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j$(nproc)
sudo make install
```

### Service Installation

```bash
# Create system user
sudo useradd -r -s /bin/false eos_server

# Install systemd service
sudo cp deploy/enterprise-os.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable enterprise-os
```

## Configuration

### Environment Variables

Create `/etc/enterprise-os/env`:

```bash
# Database
export EOS_DB_PASSWORD="$(openssl rand -base64 32)"

# JWT Secret  
export EOS_JWT_SECRET="$(openssl rand -base64 64)"

# Storage
export EOS_STORAGE_ROOT="/var/lib/enterprise-os/files"

# Logging
export EOS_LOG_LEVEL="info"
```

### Server Configuration

Edit `/etc/enterprise-os/server.conf`:

```ini
[database]
host = localhost
port = 5432
dbname = enterprise_os
user = eos_server
password = ${EOS_DB_PASSWORD}
pool_size = 10

[network]
listen_address = 0.0.0.0
api_port = 8443
zmq_port = 5555

[security]
tls_cert = /etc/enterprise-os/certs/server.crt
tls_key = /etc/enterprise-os/certs/server.key
ca_cert = /etc/enterprise-os/certs/ca.crt
jwt_secret = ${EOS_JWT_SECRET}
token_expiry = 3600
```

## Database Setup

### Initialize PostgreSQL

```bash
# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE enterprise_os;
CREATE USER eos_server WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE enterprise_os TO eos_server;
EOF
```

### Run Schema Migration

```bash
# Initialize schema (automatic on first start)
/opt/enterprise-os/bin/enterprise-os-server --init-db

# Or manually import
sudo -u postgres psql enterprise_os < /opt/enterprise-os/schema/init.sql
```

### Database Maintenance

```bash
# Daily backup (add to cron)
00 02 * * * /opt/enterprise-os/scripts/backup-db.sh

# Weekly vacuum
0 3 * * 0 sudo -u postgres vacuumdb -z enterprise_os

# Check database size
sudo -u postgres psql -c "SELECT pg_size_pretty(pg_database_size('enterprise_os'));"
```

## Security Hardening

### TLS Certificate Generation

```bash
# Create CA
openssl req -x509 -newkey rsa:4096 \
  -keyout /etc/enterprise-os/certs/ca.key \
  -out /etc/enterprise-os/certs/ca.crt \
  -days 365 -nodes \
  -subj "/CN=Enterprise OS CA"

# Create server certificate
openssl req -newkey rsa:4096 -nodes \
  -keyout /etc/enterprise-os/certs/server.key \
  -out /etc/enterprise-os/certs/server.csr \
  -subj "/CN=enterprise-os.local"

openssl x509 -req \
  -in /etc/enterprise-os/certs/server.csr \
  -CA /etc/enterprise-os/certs/ca.crt \
  -CAkey /etc/enterprise-os/certs/ca.key \
  -CAcreateserial \
  -out /etc/enterprise-os/certs/server.crt \
  -days 365

# Set permissions
chmod 600 /etc/enterprise-os/certs/*.key
chmod 644 /etc/enterprise-os/certs/*.crt
chown -R eos_server:eos_server /etc/enterprise-os/certs/
```

### Firewall Configuration

```bash
# Allow HTTPS API
sudo ufw allow 8443/tcp

# Allow ZeroMQ (internal only)
sudo ufw allow from 10.0.0.0/8 to any port 5555

# Enable firewall
sudo ufw enable
```

### SELinux (RHEL/CentOS)

```bash
# Set context for binaries
sudo semanage fcontext -a -t bin_t "/opt/enterprise-os/bin(/.*)?"
sudo restorecon -R /opt/enterprise-os/bin

# Allow network binding
sudo setsebool -P httpd_can_network_connect 1
```

## Backup & Recovery

### Automated Backup Script

Create `/opt/enterprise-os/scripts/backup-db.sh`:

```bash
#!/bin/bash
BACKUP_DIR="/var/backup/enterprise-os"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"

# Database backup
pg_dump -U eos_server enterprise_os | \
  gzip > "$BACKUP_DIR/database_$DATE.sql.gz"

# File storage backup
tar czf "$BACKUP_DIR/files_$DATE.tar.gz" \
  /var/lib/enterprise-os/files/

# Rotate old backups (keep 30 days)
find "$BACKUP_DIR" -name "*.gz" -mtime +30 -delete

echo "Backup completed: $DATE"
```

### Recovery Procedure

```bash
# Stop service
sudo systemctl stop enterprise-os

# Restore database
gunzip -c /var/backup/enterprise-os/database_20231201_020000.sql.gz | \
  sudo -u postgres psql enterprise_os

# Restore files
sudo tar xzf /var/backup/enterprise-os/files_20231201_020000.tar.gz \
  -C /var/lib/enterprise-os/

# Start service
sudo systemctl start enterprise-os
```

## Monitoring

### System Logs

```bash
# View service logs
sudo journalctl -u enterprise-os -f

# Application logs
tail -f /var/log/enterprise-os/enterprise-os.log

# Audit logs
tail -f /var/log/enterprise-os/audit.log
```

### Health Check

```bash
# Check API status
curl -k https://localhost:8443/api/status

# Check database connection
sudo -u postgres psql enterprise_os -c "SELECT version();"

# Check ZeroMQ
netstat -tulpn | grep 5555
```

### Performance Monitoring

```bash
# Database performance
sudo -u postgres psql enterprise_os << EOF
SELECT 
  schemaname,
  tablename,
  seq_scan,
  idx_scan
FROM pg_stat_user_tables
ORDER BY seq_scan DESC;
EOF

# Process monitoring
ps aux | grep enterprise-os-server
top -p $(pgrep enterprise-os)
```

## Troubleshooting

### Common Issues

**Service won't start**
```bash
# Check logs
sudo journalctl -u enterprise-os -n 50

# Verify configuration
/opt/enterprise-os/bin/enterprise-os-server --check-config

# Check file permissions
ls -l /etc/enterprise-os/
```

**Database connection errors**
```bash
# Test connection
psql -h localhost -U eos_server -d enterprise_os

# Check PostgreSQL status
sudo systemctl status postgresql

# Review PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-14-main.log
```

**High CPU usage**
```bash
# Identify bottleneck
pidstat -u 1 -p $(pgrep enterprise-os)

# Check database queries
sudo -u postgres psql enterprise_os -c \
  "SELECT pid, usename, state, query FROM pg_stat_activity;"
```

**Memory leaks**
```bash
# Monitor memory
watch -n 1 'ps -o pid,rss,cmd -p $(pgrep enterprise-os)'

# Enable verbose logging
export EOS_LOG_LEVEL=trace
sudo systemctl restart enterprise-os
```

### Emergency Procedures

**Complete system lockdown**
```bash
# Trigger firewall lockout
curl -X POST -k https://localhost:8443/api/security/lockout \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

**Force password reset**
```bash
# Reset admin password
/opt/enterprise-os/bin/eos-admin reset-password admin
```

## Support

- Documentation: https://docs.enterprise-os.local
- Bug Reports: https://github.com/enterprise/enterprise-os/issues
- Security Issues: security@enterprise-os.local
