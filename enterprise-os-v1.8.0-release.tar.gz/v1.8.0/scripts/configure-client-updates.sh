#!/bin/bash
# Enterprise OS - Client Update Configuration
# Configures client to receive updates from Enterprise OS repository

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

UPDATE_SERVER="${1:-update.enterprise-os.local}"
CHANNEL="${2:-stable}"

echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}Enterprise OS Update Client Setup${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""

# Step 1: Download and install GPG key
echo -e "${YELLOW}[1/4] Installing repository GPG key...${NC}"
curl -fsSL "https://$UPDATE_SERVER/enterprise-os.gpg.key" | \
    gpg --dearmor | \
    tee /usr/share/keyrings/enterprise-os.gpg > /dev/null

# Step 2: Add repository to sources
echo -e "${YELLOW}[2/4] Adding repository to sources...${NC}"
cat > /etc/apt/sources.list.d/enterprise-os.list << EOF
# Enterprise OS Update Repository
deb [signed-by=/usr/share/keyrings/enterprise-os.gpg] https://$UPDATE_SERVER $CHANNEL main
EOF

# Step 3: Configure unattended upgrades
echo -e "${YELLOW}[3/4] Configuring automatic updates...${NC}"
apt update
apt install -y unattended-upgrades apt-listchanges

cat > /etc/apt/apt.conf.d/50unattended-upgrades << EOF
// Automatically upgrade packages from Enterprise OS
Unattended-Upgrade::Allowed-Origins {
    "Enterprise OS:$CHANNEL";
};

// List of packages to NOT automatically upgrade
Unattended-Upgrade::Package-Blacklist {
};

// Split the upgrade into smallest possible chunks
Unattended-Upgrade::MinimalSteps "true";

// Install updates automatically
Unattended-Upgrade::InstallOnShutdown "false";

// Send email on errors
Unattended-Upgrade::Mail "root";
Unattended-Upgrade::MailReport "on-change";

// Automatically reboot if required
Unattended-Upgrade::Automatic-Reboot "true";
Unattended-Upgrade::Automatic-Reboot-Time "03:00";

// Remove unused dependencies
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";

// Enable logging
Unattended-Upgrade::SyslogEnable "true";
EOF

cat > /etc/apt/apt.conf.d/20auto-upgrades << EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF

# Step 4: Test configuration
echo -e "${YELLOW}[4/4] Testing configuration...${NC}"
apt update

if apt-cache policy | grep -q "Enterprise OS"; then
    echo -e "${GREEN}✓ Repository configured successfully${NC}"
else
    echo -e "${RED}✗ Repository not found${NC}"
    exit 1
fi

# Create update check service
cat > /etc/systemd/system/eos-update-check.service << 'EOF'
[Unit]
Description=Enterprise OS Update Checker
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/eos-update-check
User=root

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/eos-update-check.timer << 'EOF'
[Unit]
Description=Check for Enterprise OS updates daily
Requires=eos-update-check.service

[Timer]
OnCalendar=daily
OnBootSec=5min
Persistent=true

[Install]
WantedBy=timers.target
EOF

# Create update check script
cat > /usr/local/bin/eos-update-check << 'EOF'
#!/bin/bash
# Check for Enterprise OS updates and report to server

LOG_FILE="/var/log/enterprise-os/updates.log"
API_URL="https://enterprise-os.local:8443/api/updates/report"

mkdir -p /var/log/enterprise-os

# Update package lists
apt update >> "$LOG_FILE" 2>&1

# Check for updates
UPDATES=$(apt list --upgradable 2>/dev/null | grep -c "^")

if [ "$UPDATES" -gt 0 ]; then
    echo "$(date): $UPDATES updates available" >> "$LOG_FILE"
    
    # Report to server
    curl -k -X POST "$API_URL" \
        -H "Content-Type: application/json" \
        -d "{\"device_id\":\"$(hostname)\",\"updates_available\":$UPDATES}" \
        >> "$LOG_FILE" 2>&1
fi
EOF

chmod +x /usr/local/bin/eos-update-check

systemctl daemon-reload
systemctl enable eos-update-check.timer
systemctl start eos-update-check.timer

echo ""
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}Client Configuration Complete!${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""
echo "Update server: $UPDATE_SERVER"
echo "Channel: $CHANNEL"
echo ""
echo "Updates will be:"
echo "  - Checked daily"
echo "  - Downloaded automatically"
echo "  - Installed at 03:00 AM"
echo "  - System will reboot if needed"
echo ""
echo "Manual update: sudo apt update && sudo apt upgrade"
echo "Check status: systemctl status eos-update-check.timer"
echo "View logs: tail -f /var/log/enterprise-os/updates.log"
