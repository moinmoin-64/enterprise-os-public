#!/bin/bash
# Enterprise OS - Database Initialization and Migration Tool

set -e

DB_HOST="${EOS_DB_HOST:-localhost}"
DB_PORT="${EOS_DB_PORT:-5432}"
DB_NAME="${EOS_DB_NAME:-enterprise_os}"
DB_USER="${EOS_DB_USER:-eos_admin}"
DB_PASSWORD="${EOS_DB_PASSWORD}"

SCHEMA_DIR="/opt/enterprise-os/schema"

echo "=== Enterprise OS Database Initialization ==="
echo ""

if [ -z "$DB_PASSWORD" ]; then
    echo "ERROR: EOS_DB_PASSWORD environment variable not set"
    exit 1
fi

# Test database connection
echo "Testing database connection..."
export PGPASSWORD="$DB_PASSWORD"

if ! psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c '\q' 2>/dev/null; then
    echo "ERROR: Cannot connect to PostgreSQL"
    exit 1
fi

echo "✓ Database connection successful"

# Check if database exists
if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -lqt | cut -d \| -f 1 | grep -qw "$DB_NAME"; then
    echo "Database '$DB_NAME' already exists"
    read -p "Drop and recreate? (y/N): " RECREATE
    
    if [ "$RECREATE" = "y" ]; then
        echo "Dropping database..."
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "DROP DATABASE $DB_NAME;"
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "CREATE DATABASE $DB_NAME;"
        echo "✓ Database recreated"
    fi
else
    echo "Creating database..."
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "CREATE DATABASE $DB_NAME;"
    echo "✓ Database created"
fi

# Import schemas
echo ""
echo "Importing database schemas..."

schemas=(
    "gold_edition_v16.sql"
)

for schema in "${schemas[@]}"; do
    schema_file="$SCHEMA_DIR/$schema"
    
    if [ -f "$schema_file" ]; then
        echo "  Importing $schema..."
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -f "$schema_file" -q
        echo "  ✓ $schema imported"
    else
        echo "  WARNING: $schema_file not found"
    fi
done

# Create default roles
echo ""
echo "Creating default roles..."
psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" <<EOF
INSERT INTO roles (role_id, role_name, description, permissions)
VALUES 
    (1, 'system_admin', 'System Administrator', '{"all": true}'::jsonb),
    (2, 'it_admin', 'IT Administrator', '{"manage_devices": true, "manage_users": true}'::jsonb),
    (3, 'hr_manager', 'HR Manager', '{"manage_employees": true, "manage_contracts": true}'::jsonb),
    (4, 'finance_manager', 'Finance Manager', '{"manage_accounting": true, "view_reports": true}'::jsonb),
    (5, 'employee', 'Regular Employee', '{"access_portal": true}'::jsonb)
ON CONFLICT (role_id) DO NOTHING;

INSERT INTO departments (department_id, department_name, vlan_id, network_segment)
VALUES
    (10, 'Executive', 10, '10.0.10.0/24'),
    (20, 'HR', 20, '10.0.20.0/24'),
    (30, 'Finance', 30, '10.0.30.0/24'),
    (40, 'IT', 40, '10.0.40.0/24'),
    (50, 'R&D', 50, '10.0.50.0/24'),
    (60, 'Sales', 60, '10.0.60.0/24')
ON CONFLICT (department_id) DO NOTHING;
EOF

echo "✓ Default roles and departments created"

# Create migration tracking table
echo ""
echo "Setting up migration tracking..."
psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" <<EOF
CREATE TABLE IF NOT EXISTS schema_migrations (
    migration_id SERIAL PRIMARY KEY,
    migration_name VARCHAR(255) UNIQUE NOT NULL,
    applied_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO schema_migrations (migration_name)
VALUES 
    ('001_initial_schema'),
    ('002_crm_module'),
    ('003_building_iot'),
    ('004_quantum_safe_audit'),
    ('005_accounting_ledger'),
    ('006_mobile_field_service')
ON CONFLICT (migration_name) DO NOTHING;
EOF

echo "✓ Migration tracking configured"

# Verify installation
echo ""
echo "Verifying database installation..."

TABLE_COUNT=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';")

echo "  Tables created: $TABLE_COUNT"

if [ "$TABLE_COUNT" -lt 40 ]; then
    echo "  WARNING: Expected at least 40 tables for Gold Edition, found $TABLE_COUNT"
fi

# Create database backup
echo ""
echo "Creating initial backup..."
BACKUP_FILE="/var/backups/enterprise-os/initial-$(date +%Y%m%d-%H%M%S).dump"
mkdir -p /var/backups/enterprise-os
pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -F c -f "$BACKUP_FILE"
echo "✓ Backup created: $BACKUP_FILE"

echo ""
echo "=== Database Initialization Complete ==="
echo ""
echo "Database: $DB_NAME"
echo "Host: $DB_HOST:$DB_PORT"
echo "Tables: $TABLE_COUNT"
echo ""
echo "Default roles created:"
echo "  - system_admin (ID: 1)"
echo "  - it_admin (ID: 2)"
echo "  - hr_manager (ID: 3)"
echo "  - finance_manager (ID: 4)"
echo "  - employee (ID: 5)"
echo ""
echo "Next: Run /opt/enterprise-os/scripts/setup-wizard.sh"
echo ""
