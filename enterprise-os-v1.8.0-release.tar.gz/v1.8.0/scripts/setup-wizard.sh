#!/bin/bash
# Enterprise OS - Interactive Setup Wizard
# Guides administrator through initial system configuration

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

clear
echo -e "${BLUE}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║      Enterprise OS - Initial Setup Wizard                ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}ERROR: Please run as root${NC}"
    exit 1
fi

echo "This wizard will guide you through the initial setup."
echo ""
read -p "Press Enter to continue..."

# Step 1: Company Information
echo ""
echo -e "${YELLOW}=== Step 1: Company Information ===${NC}"
read -p "Company Name: " COMPANY_NAME
read -p "Company Domain (e.g., company.local): " COMPANY_DOMAIN
read -p "Admin Email: " ADMIN_EMAIL

# Step 2: Network Configuration
echo ""
echo -e "${YELLOW}=== Step 2: Network Configuration ===${NC}"
echo "Current network interfaces:"
ip -br addr show

read -p "Primary Network Interface (e.g., eth0): " PRIMARY_IFACE
read -p "Server IP Address (e.g., 10.0.100.10): " SERVER_IP
read -p "Netmask (e.g., 255.255.255.0): " NETMASK
read -p "Gateway: " GATEWAY
read -p "DNS Server 1: " DNS1
read -p "DNS Server 2 (optional): " DNS2

# Step 3: Database Configuration
echo ""
echo -e "${YELLOW}=== Step 3: Database Configuration ===${NC}"
echo "A secure password has been generated for the database."
echo "You can generate a new one or keep the existing one."
read -p "Generate new database password? (y/N): " GEN_DB_PASS

if [ "$GEN_DB_PASS" = "y" ]; then
    NEW_DB_PASSWORD=$(openssl rand -base64 32)
    export EOS_DB_PASSWORD="$NEW_DB_PASSWORD"
    echo "  New password generated"
fi

# Step 4: Create initial admin user
echo ""
echo -e "${YELLOW}=== Step 4: Create Administrator Account ===${NC}"
read -p "Admin Username: " ADMIN_USERNAME
read -sp "Admin Password: " ADMIN_PASSWORD
echo ""
read -sp "Confirm Password: " ADMIN_PASSWORD_CONFIRM
echo ""

if [ "$ADMIN_PASSWORD" != "$ADMIN_PASSWORD_CONFIRM" ]; then
    echo "Passwords do not match!"
    exit 1
fi

# Hash password
ADMIN_PASSWORD_HASH=$(echo -n "$ADMIN_PASSWORD" | sha256sum | awk '{print $1}')

# Step 5: Department Setup
echo ""
echo -e "${YELLOW}=== Step 5: Department Configuration ===${NC}"
echo "Configure initial departments (you can add more later)"
echo ""

DEPARTMENTS=()
while true; do
    read -p "Department name (or 'done' to finish): " DEPT_NAME
    if [ "$DEPT_NAME" = "done" ]; then
        break
    fi
    
    read -p "VLAN ID for $DEPT_NAME: " VLAN_ID
    read -p "Network segment (e.g., 10.0.20.0/24): " NETWORK_SEGMENT
    
    DEPARTMENTS+=("$DEPT_NAME|$VLAN_ID|$NETWORK_SEGMENT")
    echo "  Added: $DEPT_NAME"
done

# Step 6: Access Control Terminals
echo ""
echo -e "${YELLOW}=== Step 6: Register Access Terminals ===${NC}"
read -p "Number of face recognition terminals to register: " NUM_TERMINALS

TERMINALS=()
for ((i=1; i<=NUM_TERMINALS; i++)); do
    echo "Terminal #$i:"
    read -p "  Identifier (e.g., TERM-ENTRANCE-01): " TERM_ID
    read -p "  Location: " TERM_LOCATION
    read -p "  IP Address: " TERM_IP
    
    TERMINALS+=("$TERM_ID|$TERM_LOCATION|$TERM_IP")
done

# Step 7: Building IoT Devices
echo ""
echo -e "${YELLOW}=== Step 7: Building Automation (Optional) ===${NC}"
read -p "Configure building automation now? (y/N): " CONFIG_IOT

DOORS=()
CAMERAS=()
if [ "$CONFIG_IOT" = "y" ]; then
    read -p "Number of doors to configure: " NUM_DOORS
    for ((i=1; i<=NUM_DOORS; i++)); do
        echo "Door #$i:"
        read -p "  Identifier: " DOOR_ID
        read -p "  Location: " DOOR_LOC
        read -p "  Zone: " DOOR_ZONE
        read -p "  Controller IP: " DOOR_IP
        
        DOORS+=("$DOOR_ID|$DOOR_LOC|$DOOR_ZONE|$DOOR_IP")
    done
    
    read -p "Number of cameras to configure: " NUM_CAMERAS
    for ((i=1; i<=NUM_CAMERAS; i++)); do
        echo "Camera #$i:"
        read -p "  Identifier: " CAM_ID
        read -p "  Location: " CAM_LOC
        read -p "  Stream URL: " CAM_URL
        
        CAMERAS+=("$CAM_ID|$CAM_LOC|$CAM_URL")
    done
fi

# Step 8: Apply Configuration
echo ""
echo -e "${YELLOW}=== Step 8: Applying Configuration ===${NC}"
echo "Please review your settings:"
echo ""
echo "Company: $COMPANY_NAME"
echo "Domain: $COMPANY_DOMAIN"
echo "Admin: $ADMIN_USERNAME"
echo "Departments: ${#DEPARTMENTS[@]}"
echo "Terminals: ${#TERMINALS[@]}"
echo ""
read -p "Apply this configuration? (y/N): " CONFIRM

if [ "$CONFIRM" != "y" ]; then
    echo "Setup cancelled"
    exit 0
fi

echo "Applying configuration..."

# Create SQL script for initial data
cat > /tmp/eos-initial-data.sql <<EOF
-- Create initial admin user
INSERT INTO users (username, email, password_hash, role_id, hierarchy_level, is_active)
VALUES ('$ADMIN_USERNAME', '$ADMIN_EMAIL', '$ADMIN_PASSWORD_HASH', 1, 10, true);

-- Create departments
EOF

DEPT_ID=10
for dept in "${DEPARTMENTS[@]}"; do
    IFS='|' read -r name vlan network <<< "$dept"
    echo "INSERT INTO departments (department_id, department_name, vlan_id, network_segment) VALUES ($DEPT_ID, '$name', $vlan, '$network');" >> /tmp/eos-initial-data.sql
    DEPT_ID=$((DEPT_ID + 10))
done

# Register terminals
echo "" >> /tmp/eos-initial-data.sql
for term in "${TERMINALS[@]}"; do
    IFS='|' read -r id location ip <<< "$term"
    echo "INSERT INTO terminals (terminal_identifier, location, terminal_type, ip_address, is_active) VALUES ('$id', '$location', 'face', '$ip', true);" >> /tmp/eos-initial-data.sql
done

# Register doors
if [ ${#DOORS[@]} -gt 0 ]; then
    echo "" >> /tmp/eos-initial-data.sql
    for door in "${DOORS[@]}"; do
        IFS='|' read -r id location zone ip <<< "$door"
        echo "INSERT INTO doors (door_identifier, location, zone, controller_ip, is_locked, is_active) VALUES ('$id', '$location', '$zone', '$ip', true, true);" >> /tmp/eos-initial-data.sql
    done
fi

# Register cameras
if [ ${#CAMERAS[@]} -gt 0 ]; then
    echo "" >> /tmp/eos-initial-data.sql
    for camera in "${CAMERAS[@]}"; do
        IFS='|' read -r id location url <<< "$camera"
        echo "INSERT INTO cameras (camera_identifier, location, stream_url, is_active) VALUES ('$id', '$location', '$url', true);" >> /tmp/eos-initial-data.sql
    done
fi

# Execute SQL
sudo -u postgres psql -d enterprise_os -f /tmp/eos-initial-data.sql
rm /tmp/eos-initial-data.sql

# Configure network
cat > /etc/netplan/01-enterprise-os.yaml <<EOF
network:
  version: 2
  ethernets:
    $PRIMARY_IFACE:
      addresses:
        - $SERVER_IP/$NETMASK
      gateway4: $GATEWAY
      nameservers:
        addresses:
          - $DNS1
EOF

if [ -n "$DNS2" ]; then
    echo "          - $DNS2" >> /etc/netplan/01-enterprise-os.yaml
fi

netplan apply

# Step 8: Register Terminals
echo ""
echo -e "${YELLOW}=== Step 8: Access Control Terminals ===${NC}"
read -p "Number of access control terminals to register: " TERMINAL_COUNT

for ((i=1; i<=TERMINAL_COUNT; i++)); do
    echo ""
    echo "Terminal #$i:"
    read -p "  Terminal ID (e.g., TERM-001): " TERM_ID
    read -p "  Location: " TERM_LOC
    read -p "  IP Address: " TERM_IP
    read -p "  Type (entrance/exit/both): " TERM_TYPE
    
    psql -U eos_admin -d enterprise_os << EOF
INSERT INTO terminals (terminal_identifier, location, terminal_type, ip_address)
VALUES ('$TERM_ID', '$TERM_LOC', '$TERM_TYPE', '$TERM_IP');
EOF
    
    echo "  ✓ Terminal $TERM_ID registered"
    
    # Optionally deploy terminal software
    read -p "  Deploy terminal software to $TERM_IP now? (y/N): " DEPLOY_TERM
    if [ "$DEPLOY_TERM" = "y" ]; then
        if [ -f "/opt/enterprise-os/scripts/build-terminal.sh" ]; then
            /opt/enterprise-os/scripts/build-terminal.sh
            # SCP and install would go here
            echo "  Terminal software deployment initiated"
        fi
    fi
done

# Step 9: Dashboard Installation
echo ""
echo -e "${YELLOW}=== Step 9: Dashboard Installation ===${NC}"
read -p "Install dashboard applications now? (y/N): " INSTALL_DASH

if [ "$INSTALL_DASH" = "y" ]; then
    /opt/enterprise-os/scripts/install-dashboards.sh
else
    echo "  Skipped. You can install later with:"
    echo "  /opt/enterprise-os/scripts/install-dashboards.sh"
fi

echo ""
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}Setup Complete!${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""
echo "Configuration Summary:"
echo "  Server IP: $SERVER_IP"
echo "  Admin User: $ADMIN_USERNAME"
echo "  Departments: ${#DEPARTMENTS[@]}"
echo "  Terminals: ${#TERMINALS[@]}"
echo "  Doors: ${#DOORS[@]}"
echo "  Cameras: ${#CAMERAS[@]}"
echo ""
echo "Next steps:"
echo "1. Start the service: systemctl start enterprise-os"
echo "2. Access web interface: https://$SERVER_IP:8443"
echo "3. Login with: $ADMIN_USERNAME"
echo ""
echo "Full documentation: /opt/enterprise-os/docs/"
echo ""
