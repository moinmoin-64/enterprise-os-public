#!/bin/bash
# Database Health Check Script

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "======================================"
echo "Database Health Check"
echo "======================================"
echo ""

# Check PostgreSQL is running
echo -n "PostgreSQL Service: "
if systemctl is-active --quiet postgresql; then
    echo -e "${GREEN}RUNNING${NC}"
else
    echo -e "${RED}NOT RUNNING${NC}"
    exit 1
fi

# Check database exists
echo -n "Database Exists: "
if psql -U eos_admin -lqt | cut -d \| -f 1 | grep -qw enterprise_os; then
    echo -e "${GREEN}YES${NC}"
else
    echo -e "${RED}NO${NC}"
    exit 1
fi

# Check connection
echo -n "Connection Test: "
if psql -U eos_admin -d enterprise_os -c "SELECT 1;" > /dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
else
    echo -e "${RED}FAILED${NC}"
    exit 1
fi

# Check table count
echo -n "Tables: "
TABLE_COUNT=$(psql -U eos_admin -d enterprise_os -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';")
echo -e "${GREEN}$TABLE_COUNT${NC}"

# Check critical tables
echo "Critical Tables:"
CRITICAL_TABLES=("users" "roles" "devices" "terminals" "access_logs" "security_alerts")
for table in "${CRITICAL_TABLES[@]}"; do
    echo -n "  - $table: "
    if psql -U eos_admin -d enterprise_os -t -c "SELECT COUNT(*) FROM $table;" > /dev/null 2>&1; then
        COUNT=$(psql -U eos_admin -d enterprise_os -t -c "SELECT COUNT(*) FROM $table;")
        echo -e "${GREEN}$COUNT rows${NC}"
    else
        echo -e "${RED}MISSING${NC}"
    fi
done

# Check active connections
echo -n "Active Connections: "
CONN_COUNT=$(psql -U eos_admin -d enterprise_os -t -c "SELECT COUNT(*) FROM pg_stat_activity WHERE datname = 'enterprise_os';")
echo -e "${GREEN}$CONN_COUNT${NC}"

# Check database size
echo -n "Database Size: "
DB_SIZE=$(psql -U eos_admin -d enterprise_os -t -c "SELECT pg_size_pretty(pg_database_size('enterprise_os'));")
echo -e "${GREEN}$DB_SIZE${NC}"

# Check last backup
echo -n "Last Backup: "
if [ -d "/backup" ]; then
    LAST_BACKUP=$(ls -t /backup/enterprise_os_*.sql.gz 2>/dev/null | head -1)
    if [ -n "$LAST_BACKUP" ]; then
        BACKUP_DATE=$(stat -c %y "$LAST_BACKUP" | cut -d' ' -f1)
        echo -e "${GREEN}$BACKUP_DATE${NC}"
    else
        echo -e "${YELLOW}NONE FOUND${NC}"
    fi
else
    echo -e "${YELLOW}BACKUP DIR NOT FOUND${NC}"
fi

echo ""
echo -e "${GREEN}Health check complete!${NC}"
