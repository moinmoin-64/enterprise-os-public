#!/bin/bash
set -e

# Enterprise OS HAProxy Setup Script

if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root"
  exit 1
fi

echo "Installing HAProxy..."
apt-get update
apt-get install -y haproxy

echo "Configuring HAProxy..."
cp config/haproxy.cfg /etc/haproxy/haproxy.cfg

# Check if cert exists, if not generate self-signed
if [ ! -f /etc/haproxy/certs/enterprise-os.pem ]; then
    echo "Generating self-signed SSL certificate..."
    mkdir -p /etc/haproxy/certs
    openssl req -x509 -newkey rsa:4096 -keyout /etc/haproxy/certs/enterprise-os.key -out /etc/haproxy/certs/enterprise-os.crt -days 365 -nodes -subj "/C=US/ST=State/L=City/O=EnterpriseOS/CN=enterprise-os.local"
    cat /etc/haproxy/certs/enterprise-os.crt /etc/haproxy/certs/enterprise-os.key > /etc/haproxy/certs/enterprise-os.pem
    chmod 600 /etc/haproxy/certs/enterprise-os.pem
fi

echo "Validating config..."
haproxy -c -f /etc/haproxy/haproxy.cfg

echo "Restarting HAProxy..."
systemctl restart haproxy

echo "HAProxy Load Balancer is running!"
echo "Stats available at http://localhost:8404/monitor"
