#!/bin/bash
# Enterprise OS - Automated Server Installation
# This script fully automates the server installation process

set -e  # Exit on error
set -o pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/enterprise-os"
CONFIG_DIR="/etc/enterprise-os"
DATA_DIR="/var/lib/enterprise-os"
LOG_DIR="/var/log/enterprise-os"
BACKUP_DIR="/var/backups/enterprise-os"

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}ERROR: Please run as root (use sudo)${NC}"
    exit 1
fi

echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}Enterprise OS - Automated Installer${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""

# Step 1: System Requirements Check
echo -e "${YELLOW}[1/12] Checking system requirements...${NC}"
CORES=$(nproc)
RAM_GB=$(free -g | awk '/^Mem:/{print $2}')
DISK_GB=$(df -BG / | awk 'NR==2 {print $4}' | sed 's/G//')

echo "  CPU Cores: $CORES"
echo "  RAM: ${RAM_GB}GB"
echo "  Disk Space: ${DISK_GB}GB"

if [ "$CORES" -lt 4 ]; then
    echo -e "${RED}WARNING: Minimum 4 CPU cores recommended${NC}"
fi

if [ "$RAM_GB" -lt 8 ]; then
    echo -e "${RED}ERROR: Minimum 8GB RAM required${NC}"
    exit 1
fi

if [ "$DISK_GB" -lt 50 ]; then
    echo -e "${RED}ERROR: Minimum 50GB free disk space required${NC}"
    exit 1
fi

# Step 2: Install system dependencies
echo -e "${YELLOW}[2/12] Installing system dependencies...${NC}"
apt-get update
apt-get install -y \
    build-essential cmake git curl wget \
    postgresql-14 postgresql-contrib \
    libzmq3-dev libssl-dev libcurl4-openssl-dev \
    libyaml-cpp-dev nlohmann-json3-dev \
    libspdlog-dev redis-server nginx \
    nftables fail2ban auditd \
    python3 python3-pip python3-zmq \
    python3-sklearn python3-numpy python3-scipy \
    python3-joblib python3-pandas \
    python3-opencv python3-face-recognition \
    libdlib-dev libblas-dev liblapack-dev \
    libpq-dev \
    qt6-base-dev qt6-charts-dev qt6-websockets-dev

# Step 3: Create system user
echo -e "${YELLOW}[3/12] Creating system user...${NC}"
if ! id -u eos-admin > /dev/null 2>&1; then
    useradd -r -s /bin/bash -d /var/lib/enterprise-os -m eos-admin
    echo "  Created user: eos-admin"
else
    echo "  User eos-admin already exists"
fi

# Step 4: Create directory structure
echo -e "${YELLOW}[4/12] Creating directory structure...${NC}"
mkdir -p "$INSTALL_DIR"
mkdir -p "$CONFIG_DIR"/{certs,profiles}
mkdir -p "$DATA_DIR"/{files,images,recordings}
mkdir -p "$LOG_DIR"
mkdir -p "$BACKUP_DIR"

chown -R eos-admin:eos-admin "$DATA_DIR"
chown -R eos-admin:eos-admin "$LOG_DIR"
chown -R eos-admin:eos-admin "$BACKUP_DIR"

# Step 5: Clone or copy source code
echo -e "${YELLOW}[5/12] Installing Enterprise OS source...${NC}"
if [ -d "/tmp/enterprise-os" ]; then
    cp -r /tmp/enterprise-os/* "$INSTALL_DIR/"
    echo "  Copied from /tmp/enterprise-os"
else
    echo "  ERROR: Source not found in /tmp/enterprise-os"
    echo "  Please copy the source code to /tmp/enterprise-os first"
    exit 1
fi

# Step 6: Build Enterprise OS
echo -e "${YELLOW}[6/12] Building Enterprise OS...${NC}"
cd "$INSTALL_DIR"
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j$(nproc)
make install

# Step 7: Database setup
echo -e "${YELLOW}[7/12] Setting up PostgreSQL database...${NC}"

# Generate random password if not set
if [ -z "$EOS_DB_PASSWORD" ]; then
    EOS_DB_PASSWORD=$(openssl rand -base64 32)
    echo "  Generated database password"
fi

# Create database and user
sudo -u postgres psql -c "CREATE DATABASE enterprise_os;" 2>/dev/null || echo "  Database already exists"
sudo -u postgres psql -c "CREATE USER eos_admin WITH ENCRYPTED PASSWORD '$EOS_DB_PASSWORD';" 2>/dev/null || echo "  User already exists"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE enterprise_os TO eos_admin;"

# Import schemas
echo "  Importing database schemas..."
sudo -u postgres psql -d enterprise_os -f "$INSTALL_DIR/schema/full_schema.sql"
sudo -u postgres psql -d enterprise_os -f "$INSTALL_DIR/schema/crm_schema.sql"
sudo -u postgres psql -d enterprise_os -f "$INSTALL_DIR/schema/building_iot_schema.sql"
sudo -u postgres psql -d enterprise_os -f "$INSTALL_DIR/schema/licensing_schema.sql"

# Enable SSL for PostgreSQL
echo "ssl = on" | sudo tee -a /etc/postgresql/14/main/postgresql.conf
systemctl restart postgresql

# Step 8: Generate JWT secret
echo -e "${YELLOW}[8/12] Generating secrets...${NC}"
if [ -z "$EOS_JWT_SECRET" ]; then
    EOS_JWT_SECRET=$(openssl rand -base64 64)
    echo "  Generated JWT secret"
fi

# Step 9: Create configuration file
echo -e "${YELLOW}[9/12] Creating configuration...${NC}"
cat > "$CONFIG_DIR/server.conf" <<EOF
[database]
host = localhost
port = 5432
name = enterprise_os
user = eos_admin
password = \${EOS_DB_PASSWORD}

[network]
listen_address = 0.0.0.0
api_port = 8443
zmq_port = 5555

[security]
tls_enabled = true
tls_cert_path = $CONFIG_DIR/certs/server-cert.pem
tls_key_path = $CONFIG_DIR/certs/server-key.pem
jwt_secret = \${EOS_JWT_SECRET}

[logging]
log_level = \${EOS_LOG_LEVEL:INFO}
log_dir = $LOG_DIR

[storage]
root_path = $DATA_DIR

[deployment]
profiles_dir = $INSTALL_DIR/deploy/distro-profiles
images_dir = $DATA_DIR/images

[licensing]
public_key = $CONFIG_DIR/license-public.pem
license_data = $CONFIG_DIR/license.dat
EOF

# Step 10: Set environment variables
echo -e "${YELLOW}[10/12] Setting environment variables...${NC}"
cat > /etc/environment <<EOF
EOS_DB_PASSWORD="$EOS_DB_PASSWORD"
EOS_JWT_SECRET="$EOS_JWT_SECRET"
EOS_LOG_LEVEL="INFO"
EOS_STORAGE_ROOT="$DATA_DIR"
PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
EOF

# Step 11: Install systemd service
echo -e "${YELLOW}[11/12] Installing systemd service...${NC}"
cp "$INSTALL_DIR/deploy/enterprise-os.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable enterprise-os

# Step 12: Setup automated backups
echo -e "${YELLOW}[12/12] Configuring automated backups...${NC}"
cp "$INSTALL_DIR/scripts/backup.sh" /usr/local/bin/eos-backup
chmod +x /usr/local/bin/eos-backup

# Add cron job
(crontab -l 2>/dev/null; echo "0 2 * * * /usr/local/bin/eos-backup") | crontab -

# Step 13: Build and install dashboards (optional)
echo -e "${YELLOW}[13/13] Building dashboard applications...${NC}"
read -p "Install dashboard applications? (y/N): " INSTALL_DASHBOARDS

if [ "$INSTALL_DASHBOARDS" = "y" ] || [ "$INSTALL_DASHBOARDS" = "Y" ]; then
    echo "  Building Admin Dashboard..."
    cd "$INSTALL_DIR/client/dashboards/admin"
    mkdir -p build && cd build
    cmake .. && make -j$(nproc)
    make install
    
    echo "  Admin Dashboard installed successfully"
    echo "  Run with: eos-admin-dashboard"
else
    echo "  Skipping dashboard installation"
    echo "  You can install later with: ./scripts/build-all-dashboards.sh"
fi

echo ""
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}Installation Complete!${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""
echo "Next steps:"
echo "1. Run the setup wizard: /usr/local/bin/eos-setup"
echo "2. Generate PKI certificates (see docs/PKI_SETUP.md)"
echo "3. Start the service: systemctl start enterprise-os"
echo ""
echo "Important credentials (save these securely!):"
echo "  Database Password: $EOS_DB_PASSWORD"
echo "  JWT Secret: $EOS_JWT_SECRET"
echo ""
echo -e "${YELLOW}These credentials have been saved to /etc/environment${NC}"
echo ""
