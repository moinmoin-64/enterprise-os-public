#!/bin/bash
set -e

# Enterprise OS Cluster Setup Script

if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root"
  exit 1
fi

ROLE=$1
PRIMARY_IP=$2

if [ -z "$ROLE" ]; then
    echo "Usage: $0 <primary|replica> [primary_ip]"
    exit 1
fi

echo "Setting up Enterprise OS Cluster Node ($ROLE)..."

# 1. Sync Configuration
echo "Syncing configuration..."
mkdir -p /etc/enterprise-os
if [ "$ROLE" == "replica" ]; then
    if [ -z "$PRIMARY_IP" ]; then
        echo "Error: Primary IP required for replica setup"
        exit 1
    fi
    # In production, use rsync or scp with keys
    # scp root@$PRIMARY_IP:/etc/enterprise-os/server.conf /etc/enterprise-os/
    echo "Configured to pull from $PRIMARY_IP"
fi

# 2. Configure Database Replication
echo "Configuring PostgreSQL Replication..."
if [ "$ROLE" == "primary" ]; then
    # Enable replication in postgresql.conf
    # wal_level = replica
    # max_wal_senders = 10
    echo "Primary DB configured for replication."
else
    # Stop DB
    systemctl stop postgresql
    # Backup existing data
    mv /var/lib/postgresql/14/main /var/lib/postgresql/14/main.bak
    # Base backup
    # PGPASSWORD=replicapass pg_basebackup -h $PRIMARY_IP -D /var/lib/postgresql/14/main -U replicator -v -P --wal-method=stream
    echo "Replica DB synced from Primary."
    systemctl start postgresql
fi

# 3. Join Cluster (Service Discovery)
echo "Registering node in cluster..."
# This would register with Consul/Etcd in a real setup
echo "Node joined cluster."

echo "Cluster setup complete!"
